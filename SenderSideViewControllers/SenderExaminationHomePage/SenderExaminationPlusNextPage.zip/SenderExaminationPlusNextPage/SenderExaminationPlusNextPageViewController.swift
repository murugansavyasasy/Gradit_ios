//
//  SenderExaminationPlusNextPageViewController.swift
//  GraditSenderExaminationMenu
//
//  Created by MACBOOKPRO on 03/12/22.
//

import UIKit
import KRProgressHUD

class SenderExaminationPlusNextPageViewController: UIViewController {
    
    
   
    @IBOutlet weak var fromDateLabel: UILabel!
    
    @IBOutlet weak var toDateLabel: UILabel!
    @IBOutlet weak var TodateView: UIViewX!
    
    @IBOutlet weak var calanderView: UIViewX!
    
    @IBOutlet weak var loginView: UIView!
    
    @IBOutlet weak var logoutView: UIView!
    
    @IBOutlet weak var changeRolesView: UIView!
    
    @IBOutlet weak var topLabels: UILabel!
    
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var clgLogoImg: UIImageView!
    @IBOutlet weak var changePasswordView: UIView!
    
    
    @IBOutlet weak var topMessageLabel: UILabel!
    
    @IBOutlet weak var termsAndConditionView: UIView!
    
    
    
    @IBOutlet weak var helpView: UIView!
    
    
    
    
    @IBOutlet weak var sideMenuView: UIView!
    
    
    @IBOutlet weak var viewTap: UIView!
    
    @IBOutlet weak var refreshView: UIView!
    
    
    
    @IBOutlet weak var faqView: UIView!
    
    @IBOutlet weak var privacyPolicyView: UIView!
    
    
    @IBOutlet weak var profileView: UIView!
    
    @IBOutlet weak var smallImg: UIImageView!
    @IBOutlet weak var bigImg: UIImageView!
    var addImageBackGroundurl : String!
    var imageWebUrl : String!
    var smallImageUrl  : String!
    

    
    
    var display_date : String!
    var memberName : String!
    var url_date : String!
    var colgImg : String!
    var priority : String!
    override func viewDidLoad() {
        super.viewDidLoad()

       print("sert5",smallImageUrl)
        
        bigImg.sd_setImage(with: URL(string: addImageBackGroundurl), placeholderImage: UIImage(named: "ic_white"))
      smallImg.sd_setImage(with: URL(string: smallImageUrl ), placeholderImage: UIImage(named: "ic_white"))

        
        fromDateLabel.text = "-SelectDate-"
        toDateLabel.text = "-SelectDate-"
        
        sideMenuView.isHidden = true
        
        let defaults = UserDefaults.standard
        memberName = defaults.string(forKey: DefaultsKeys.memberName)
        priority = defaults.string(forKey: DefaultsKeys.priority)
        colgImg = defaults.string(forKey: DefaultsKeys.colglogo)
               clgLogoImg.sd_setImage(with: URL(string:  colgImg), placeholderImage: UIImage(named: "person.fill"))
        
        topMessageLabel.text = memberName
        
        
        if priority == "p1"{
            
            topLabels.text = "Principal"
            
        }
        
        else if priority == "p4"{
            
            topLabels.text = "Student"
            
        }
        
        else if priority == "p2" || priority == "p3"{
            
            
            topLabels.text = "Teacher"
            
        }
        
        else if priority == "p5"{
            
            
            topLabels.text = "Father"
            
            
            
        }
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(adLoad))
                
        bigImg.isUserInteractionEnabled = true
        bigImg.addGestureRecognizer(singleTap)

        
        
        
        
        // tap Bar UiTapGuster.
        
        
//        let menuGestureHideView = UITapGestureRecognizer(target: self, action: #selector(menuHide))
//        tapView.addGestureRecognizer(menuGestureHideView)
        
        let menuGestureHide = UITapGestureRecognizer(target: self, action: #selector(menu))
        viewTap.addGestureRecognizer(menuGestureHide)
        
//        let notificationGesture = UITapGestureRecognizer(target: self, action: #selector(notificationVc))
//        notificationView.addGestureRecognizer(notificationGesture)
        
        let refreshGesture = UITapGestureRecognizer(target: self, action: #selector(refreshVc))
        refreshView.addGestureRecognizer(refreshGesture)
        
        
                let faqGesture = UITapGestureRecognizer(target: self, action: #selector(faqRedirect))
                faqView.addGestureRecognizer(faqGesture)
     
//        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(logoutPressed))
        let helpGesture = UITapGestureRecognizer(target: self, action: #selector(helpRedirect))
              helpView.addGestureRecognizer(helpGesture)
      //
        
        let privacyPolicyGesture = UITapGestureRecognizer(target: self, action: #selector(privacyPolicyRedirect))
               privacyPolicyView.addGestureRecognizer(privacyPolicyGesture)
       
               let termsAndConditionGesture = UITapGestureRecognizer(target: self, action: #selector(termsAndCondition))
               termsAndConditionView.addGestureRecognizer(termsAndConditionGesture)
               
              
//               let profileGesture = UITapGestureRecognizer(target: self, action: #selector(profileRedirect))
        
        
        let chagePassword = UITapGestureRecognizer(target: self, action: #selector(changePassowrdVC))
        changePasswordView.addGestureRecognizer(chagePassword)
        
        let changeRol = UITapGestureRecognizer(target: self, action: #selector(chngeVc))
        changeRolesView.addGestureRecognizer(changeRol)
        
        
                       let profileGesture = UITapGestureRecognizer(target: self, action: #selector(profileRedirect))
        profileView.addGestureRecognizer(profileGesture)

        
        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(logoutPressed))
        loginView.addGestureRecognizer(logoutGesture)
        
        
//        let menuGestureHide = UITapGestureRecognizer(target: self, action: #selector(menu))
//        viewTap.addGestureRecognizer(menuGestureHide)
//
        
        
        
        
        let calanderViewclick = UITapGestureRecognizer(target: self, action: #selector(calanderClickVc))
        calanderView.addGestureRecognizer(calanderViewclick)
        
        let todateClick = UITapGestureRecognizer(target: self, action: #selector(todateClick))
        TodateView.addGestureRecognizer(todateClick)
        
        
    }

    
    func getCurrentViewController() -> UIViewController? {
        
        if let rootController = UIApplication.shared.keyWindow?.rootViewController {
            var currentController: UIViewController! = rootController
            while( currentController.presentedViewController != nil ) {
                currentController = currentController.presentedViewController
            }
            return currentController
        }
        return nil
        
    }
    
    
    
    
    @IBAction func adLoad(){
        
        
        
        let vc = TotalAddLoadPageViewController(nibName: nil, bundle: nil)
        
        vc.AddWebUrl = imageWebUrl
        
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true,completion: nil)
        
        
    }
    
    
    
    @IBAction func calanderClickVc(){
        
        FromDate_Action()
        
        
        
    }
    
    
    
    @IBAction func todateClick(){
        
        Todate()
        
        
        
    }
    
    
    func FromDate_Action(){

            

        RPicker.selectDate(title: "Select Date", cancelText: "Cancel", datePickerMode: .date, style: .Inline, didSelectDate: {[weak self] (today_date) in

                

                self?.display_date = today_date.dateString("dd-M-yyyy")

                self?.url_date = today_date.dateString("yyyy-M-dd")

                self?.fromDateLabel.text = self!.display_date

//                self?.From_date_label.textColor = .black

                

            })

        }
    
    func Todate(){

            

        RPicker.selectDate(title: "Select Date", cancelText: "Cancel", datePickerMode: .date, style: .Inline, didSelectDate: {[weak self] (today_date) in

                

                self?.display_date = today_date.dateString("dd-M-yyyy")

                self?.url_date = today_date.dateString("yyyy-M-dd")

                self?.toDateLabel.text = self!.display_date

//                self?.From_date_label.textColor = .black

                

            })

        }
    

    @IBAction func backbtn(_ sender: Any) {
        
        dismiss(animated: true)
        
    }
    
    
    // Tab Bar Nagivation
    
    
    
    @IBAction func helpRedirect() {
        
        let vc = HelpViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func termsAndCondition() {
        
        let vc = MenuTermsViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func logoutPressed() {
        
        
        _ =  SweetAlert().showAlert(" Are you sure do you want to logout ",subTitle: "",style: .none,buttonTitle: "NO",buttonColor:.systemGray,otherButtonTitle: "YES",otherButtonColor: .systemGray){
            is_yes_click in
            if is_yes_click {
                print("pressed no button")
            }else{
                
                UserDefaults.standard.removeObject(forKey: DefaultsKeys.mobileNumber)
                
                let vc = LoginViewController(nibName: nil, bundle: nil)
                vc.modalPresentationStyle = .fullScreen
                let currentController = self.getCurrentViewController()
                currentController?.present(vc, animated: true, completion: nil)
            }
        }
    }
    
    
    @IBAction func faqRedirect() {
        print("faqRedirect")
        let vc = FaqViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func privacyPolicyRedirect() {
        
        let vc = PrivacyPolicyViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: true, completion: nil)
        
    }
    
    
    
    
    
    @IBAction func refreshVc() {
        
        print("refreshVcWork")
        KRProgressHUD.show()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
//            self.tv.reloadData()
            
            
            KRProgressHUD.dismiss()
            
        }
        
        
    }
    
    
    @IBAction func notificationVc() {
        print("NotificationViewController")
        let vc = NotificationViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: false, completion: nil)

//        vc.modalPresentationStyle = .fullScreen
        
    }
    
    
    
    
    @IBAction func menu() {
       
        if sideMenuView.isHidden == true{
            
            sideMenuView.isHidden = false
//
          
            print("menuVisble")
        }
        
        else{
            
            sideMenuView.isHidden = true
//            self.view.sendSubviewToBack(sideMenuView)
            print("mddffenuVisble")
        }
        
        
    }
   
    
    @IBAction func changePassowrdVC(){
        
        let vc = ChangePasswordViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
        currentController?.present(vc, animated: true, completion: nil)
        
//        present(vc, animated: false, completion: nil)
        
        
        
    }
    
    
    @IBAction func profileRedirect() {
        
        let vc = ProfileViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        let currentController = self.getCurrentViewController()
            currentController?.present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func chngeVc (){
        
        
        
        print("click")
        
        
    }
    
    
    


}
