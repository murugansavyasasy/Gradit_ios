//
//  SenderComunicationPlusNextPageViewController.swift
//  GraditSenderCommunicationMenu
//
//  Created by MACBOOKPRO on 07/12/22.
//

import UIKit
import KRProgressHUD

class SenderComunicationPlusNextPageViewController: UIViewController,UITextViewDelegate{

    @IBOutlet weak var discripitionView: UIViewX!
    
    @IBOutlet weak var enterDiscripitonsLabel: UILabel!
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var smallImg: UIImageView!
    
    @IBOutlet weak var bigImg: UIImageView!
    
    
    
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var topLabels: UILabel!
    
    
    @IBOutlet weak var logoutView: UIView!
    
    @IBOutlet weak var changeRolesView: UIView!
    @IBOutlet weak var profileView: UIView!
   
    @IBOutlet weak var clgLogoImg: UIImageView!
    
    @IBOutlet weak var topMessageLabel: UILabel!
    
    
    
    @IBOutlet weak var privacyPolicyView: UIView!
    
    
    
    @IBOutlet weak var faqView: UIView!
    
    
    @IBOutlet weak var viewTap: UIView!
    
    @IBOutlet weak var helpView: UIView!
    
    
    @IBOutlet weak var changePasswordView: UIView!
    
    
    @IBOutlet weak var termsAndConditionView: UIView!
    
    
    @IBOutlet weak var sideMenuView: UIView!
    
    
    
    @IBOutlet weak var refreshView: UIView!
    
    
    
    
    
    
    @IBOutlet weak var selectRecipientsView: UIViewX!
    
    @IBOutlet weak var descripitionTextField: UITextView!
    
    
    @IBOutlet weak var cancelView: UIViewX!
    
    var entierRefName : [EntiercollegeDataDetails] = []
    
    var backGroundImage : String!
    var smallImageUrl : String!
    var addWebUrl : String!
    
    
    var memberId : String!
    var priority : String!
    var collegeId : String!
    var departmentId : String!
    var sectionId : String!
    var loginType : String!
    var memberName : String!
    var colgImg    : String!
    var empty : String!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("urlss",backGroundImage)
        

        
        
        bigImg.sd_setImage(with: URL(string: backGroundImage), placeholderImage: UIImage(named: "ic_white"))


        smallImg.sd_setImage(with: URL(string: smallImageUrl), placeholderImage: UIImage(named: "ic_white"))

        
        
        
        sideMenuView.isHidden = true
        
        let defaults = UserDefaults.standard
        
        memberId = defaults.string(forKey: DefaultsKeys.memberid)
        priority = defaults.string(forKey: DefaultsKeys.priority)
        collegeId = defaults.string(forKey: DefaultsKeys.collegeid)
        departmentId = defaults.string(forKey: DefaultsKeys.deptid)
        sectionId = defaults.string(forKey: DefaultsKeys.sectionid)
        loginType = defaults.string(forKey: DefaultsKeys.loginAsType)
        memberName = defaults.string(forKey: DefaultsKeys.memberName)
        colgImg = defaults.string(forKey: DefaultsKeys.colglogo)
               clgLogoImg.sd_setImage(with: URL(string:  colgImg), placeholderImage: UIImage(named: "person.fill"))
        
        topMessageLabel.text = memberName
        
        
       
        descripitionTextField.delegate = self
        
        
        
        
        if priority == "p1"{
            
            topLabels.text = "Principal"
            
        }
        
        else if priority == "p4"{
            
            topLabels.text = "Student"
            
        }
        
        else if priority == "p2" || priority == "p3"{
            
            
            topLabels.text = "Teacher"
            
        }
        
        else if priority == "p5"{
            
            
            topLabels.text = "Father"
            
            
            
        }
        
        let disp = UITapGestureRecognizer(target: self, action: #selector(dispVc))
        discripitionView.addGestureRecognizer(disp)
        
        
        let selectRecpient = UITapGestureRecognizer(target: self, action: #selector(SelectRepVc))
        selectRecipientsView.addGestureRecognizer(selectRecpient)
        
        let cancel = UITapGestureRecognizer(target: self, action: #selector(cancelVC))
        cancelView.addGestureRecognizer(cancel)
        
        
        let profileGesture = UITapGestureRecognizer(target: self, action: #selector(profileRedirect))
        profileView.addGestureRecognizer(profileGesture)

        
        let changeRolesGesture = UITapGestureRecognizer(target: self, action: #selector(priorityVc))
        changeRolesView.addGestureRecognizer(changeRolesGesture)

        
        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(logoutPressed))
        logoutView.addGestureRecognizer(logoutGesture)
        
        
        
//        let menuGestureHideView = UITapGestureRecognizer(target: self, action: #selector(menuHide))
//        tapView.addGestureRecognizer(menuGestureHideView)
        
        let menuGestureHide = UITapGestureRecognizer(target: self, action: #selector(menu))
        viewTap.addGestureRecognizer(menuGestureHide)
        
        let notificationGesture = UITapGestureRecognizer(target: self, action: #selector(notificationVc))
        notificationView.addGestureRecognizer(notificationGesture)
        
        let refreshGesture = UITapGestureRecognizer(target: self, action: #selector(refreshVc))
        refreshView.addGestureRecognizer(refreshGesture)
        
        
                let faqGesture = UITapGestureRecognizer(target: self, action: #selector(faqRedirect))
                faqView.addGestureRecognizer(faqGesture)
     
//        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(logoutPressed))
        let helpGesture = UITapGestureRecognizer(target: self, action: #selector(helpRedirect))
              helpView.addGestureRecognizer(helpGesture)
      //
        
        let privacyPolicyGesture = UITapGestureRecognizer(target: self, action: #selector(privacyPolicyRedirect))
               privacyPolicyView.addGestureRecognizer(privacyPolicyGesture)
       
               let termsAndConditionGesture = UITapGestureRecognizer(target: self, action: #selector(termsAndCondition))
               termsAndConditionView.addGestureRecognizer(termsAndConditionGesture)
               
              
//               let profileGesture = UITapGestureRecognizer(target: self, action: #selector(profileRedirect))
        
        
        let chagePassword = UITapGestureRecognizer(target: self, action: #selector(changePassowrdVC))
        changePasswordView.addGestureRecognizer(chagePassword)
        
        
        
        
//        let menuGestureHide = UITapGestureRecognizer(target: self, action: #selector(menu))
//        viewTap.addGestureRecognizer(menuGestureHide)
//
        
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(adLoad))
                
        bigImg.isUserInteractionEnabled = true
        bigImg.addGestureRecognizer(singleTap)


        
        
        
    }
    
    
    
    
   
    
    
    
    
    
    
    
    
    
    
    @IBAction func dispVc(){
        
        
        discripitionView.isHidden = true
       
    }
    
    
    @IBAction func adLoad(){
        
        
        let vc = SendercomuniAddViewController(nibName: nil, bundle: nil)
        
        vc.AddWebUrl = addWebUrl
        
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true,completion: nil)
        
    }
    
    

//    func textViewDidBeginEditing(_ textView: UITextView) {
//
//        print("true")
//        if descripitionTextField.text == "Enter the Description" {
//            descripitionTextField.text = ""
//            descripitionTextField.textColor = UIColor.black
//            descripitionTextField.font = UIFont(name: "verdana", size: 18.0)
//        }
//    }
//
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            descripitionTextField.resignFirstResponder()
        }
        return true
    }
    
//    func textViewDidEndEditing(_ textView: UITextView) {
//        print("false")
//        if descripitionTextField.text == "" {
//            descripitionTextField.text = "Enter the Description"
//            descripitionTextField.textColor = UIColor.lightGray
//            descripitionTextField.font = UIFont(name: "verdana", size: 13.0)
//            let selectRecpient = UITapGestureRecognizer(target: self, action: #selector(SelectRepVc))
//            selectRecipientsView.addGestureRecognizer(selectRecpient)
//
//        }
//    }
    
    
    
    


    
    @IBAction func backbtn(_ sender: Any) {
        
        dismiss(animated: true)
    }
    
    
    @IBAction func SelectRepVc(){
        
        if (descripitionTextField.text!.isEmpty) && (titleTextField.text!.isEmpty) {

            
            
            print("heloo",descripitionTextField.text.count)
            SweetAlert().showAlert("Info", subTitle: "Kindly Enter Details ", style: .none, buttonTitle: "ok")

        }
        
        

       
        
        else{
            
            let vc = SelectResipientsViewController(nibName: nil, bundle: nil)
            
            vc.titlesTextField = titleTextField.text
            vc.discreptionss = descripitionTextField.text
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true,completion: nil)
            
        }
        
    
    }
    
    @IBAction func cancelVC(){
        
        dismiss(animated: true)
        
    }
    
    
    
    
    
    
    
    
    @IBAction func helpRedirect() {
        
        let vc = HelpViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
       
       present(vc, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func termsAndCondition() {
        
        let vc = MenuTermsViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
      present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func logoutPressed() {
        
        
        _ =  SweetAlert().showAlert(" Are you sure do you want to logout ",subTitle: "",style: .none,buttonTitle: "NO",buttonColor:.systemGray,otherButtonTitle: "YES",otherButtonColor: .systemGray){
            is_yes_click in
            if is_yes_click {
                print("pressed no button")
            }else{
                
                UserDefaults.standard.removeObject(forKey: DefaultsKeys.mobileNumber)
                
                let vc = LoginViewController(nibName: nil, bundle: nil)
                vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true,completion: nil)
//               present(vc, animated: true, completion: nil)
            }
        }
    }
    
    
    @IBAction func faqRedirect() {
        print("faqRedirect")
        let vc = FaqViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
       present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func privacyPolicyRedirect() {
        
        let vc = PrivacyPolicyViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
       present(vc, animated: true, completion: nil)
        
    }
    
    
    
    
    
    @IBAction func refreshVc() {
        
        print("refreshVcWork")
        KRProgressHUD.show()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
//            self.tv.reloadData()
            
            
            KRProgressHUD.dismiss()
            
        }
        
        
    }
    
    
    @IBAction func notificationVc() {
        print("NotificationViewController")
        let vc = NotificationViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true, completion: nil)

//        vc.modalPresentationStyle = .fullScreen
        
    }
    
    
    
    
    @IBAction func menu() {
       
        if sideMenuView.isHidden == true{
            
            sideMenuView.isHidden = false
//
          
            print("menuVisble")
        }
        
        else{
            
            sideMenuView.isHidden = true
//            self.view.sendSubviewToBack(sideMenuView)
            print("mddffenuVisble")
        }
        
        
    }
   
    
    @IBAction func changePassowrdVC(){
        
        let vc = ChangePasswordViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
      present(vc, animated: true, completion: nil)
        
//        present(vc, animated: false, completion: nil)
        
        
        
    }
    
    @IBAction func profileRedirect() {
        
        let vc = ProfileViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
       present(vc, animated: true, completion: nil)
        
    }
    
    
   
    
    
    @IBAction func priorityVc() {
        
        print("clicked")
        
    }
    
    
    
    
    
    
}
