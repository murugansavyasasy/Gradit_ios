//
//  SelectResipientsViewController.swift
//  Vs_GradItCollege
//
//  Created by MACBOOKPRO on 28/12/22.
//

import UIKit
import ObjectMapper
import DropDown

class SelectResipientsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var coursedropTxtLabel: UILabel!
    @IBOutlet weak var courseDropDownView: UIView!
    
    @IBOutlet weak var dropDownTextLabel: UILabel!
    @IBOutlet weak var sendView: UIViewX!
    
    @IBOutlet weak var tvTopConstain: NSLayoutConstraint!
    
   
    @IBOutlet weak var dropDownView: UIView!
    @IBOutlet weak var topIdentificationLabel: UILabel!
    @IBOutlet weak var tv: UITableView!
    
    @IBOutlet weak var entireCollegeCheckBoxView: CheckBoxTwo!
    
    
    @IBOutlet weak var cancelView: UIViewX!
    
    
    @IBOutlet weak var groupLabel: UILabel!
    
    
    @IBOutlet weak var courseLabel: UILabel!
    
    
    @IBOutlet weak var yourClassLabel: UILabel!
    
    
    @IBOutlet weak var departmentLabel: UILabel!
    
    @IBOutlet weak var yourClassesView: UIViewX!
    @IBOutlet weak var devisionTabel: UILabel!
    
    
    @IBOutlet weak var groupView: UIViewX!
    
    
    @IBOutlet weak var courseView: UIViewX!
    
    
    @IBOutlet weak var departmentView: UIViewX!
    
    
    
    @IBOutlet weak var devisionView: UIViewX!
    
    
    
    
    
    @IBOutlet weak var parentsCheckBoxView: CheckBoxTwo!
    
    
    
    @IBOutlet weak var studentCheckBoxView: CheckBoxTwo!
   
    
   
    @IBOutlet weak var staffCheckBoxView: CheckBoxTwo!
    
    
    var identifier  = "SelectRespienceCellTableViewCell"
    
    var devisionRefName : [getDivisonDataDetails] = []
    var deparmentRefName : [RepienceDeparmentDataDetails] = []
    var entierRefName : [EntiercollegeDataDetails] = []
    var groupRefName : [getGroupDataDetails] = []
    var courseRefName : [getCourseDataDetails] = []
    let dropDown = DropDown()
    var titlesTextField : String!
    var discreptionss : String!
    
    var memberId : String!
    var collegeId : String!
    var priority : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        topIdentificationLabel.text = ""

        dropDownView.isHidden = true
        
       
        
        tvTopConstain.constant = -30
        
      
        
        let defaults = UserDefaults.standard
        
        memberId = defaults.string(forKey: DefaultsKeys.memberid)
       
        collegeId = defaults.string(forKey: DefaultsKeys.collegeid)
        priority = defaults.string(forKey: DefaultsKeys.priority)
        
        let rownib = UINib(nibName: identifier, bundle: nil)
        tv.register(rownib, forCellReuseIdentifier: identifier)
        
        
        let Drops = UITapGestureRecognizer(target: self, action: #selector(dropDowVC))
        
       
        dropDownView.addGestureRecognizer(Drops)
        
        
        let CoureDrop = UITapGestureRecognizer(target: self, action: #selector(CoursedropDowVC))
        
       
        courseDropDownView.addGestureRecognizer(CoureDrop)
        
        
        let send = UITapGestureRecognizer(target: self, action: #selector(sendVc))
        
       
        sendView.addGestureRecognizer(send)
        
        
        
        let entireCollege = UITapGestureRecognizer(target: self, action: #selector(entireCollegeVc))
        
        
        entireCollegeCheckBoxView.addGestureRecognizer(entireCollege)
        
        
        let devision = UITapGestureRecognizer(target: self, action: #selector(devisionVc))
        
       
        devisionView.addGestureRecognizer(devision)
        
        
        
        
        
        let department = UITapGestureRecognizer(target: self, action: #selector(departmentVc))
        
       
        departmentView.addGestureRecognizer(department)
        
        
        
        let course = UITapGestureRecognizer(target: self, action: #selector(course))
        
        
        courseView.addGestureRecognizer(course)
        
        
        
        let yourClass = UITapGestureRecognizer(target: self, action: #selector(yourClassFunction))
        
       
        yourClassesView.addGestureRecognizer(yourClass)
        
        
        
        let groups = UITapGestureRecognizer(target: self, action: #selector(group))
        
      
        groupView.addGestureRecognizer(groups)
        
        
        let studentCheckBox = UITapGestureRecognizer(target: self, action: #selector(StudentCheckBoxVc))
        studentCheckBoxView.addGestureRecognizer(studentCheckBox)
        
        let parentCheckBox = UITapGestureRecognizer(target: self, action: #selector(parentCheckBoxVc))
        parentsCheckBoxView.addGestureRecognizer(parentCheckBox)
        
        
        let staffCheckBox = UITapGestureRecognizer(target: self, action: #selector(staffCheckBoxVC))
        staffCheckBoxView.addGestureRecognizer(staffCheckBox)
        
        
        
        
        let cancel = UITapGestureRecognizer(target: self, action: #selector(CancelVc))
        cancelView.addGestureRecognizer(cancel)
        
        
    }
    
    
    @IBAction func CoursedropDowVC(){

     
        
//        let devisions = getDivisionModal()
//
//        devisions.college_id = collegeId
//        devisions.user_id =  memberId
//
//        let devisionstr = devisions.toJSONString()
//
//
//        DivisionRequest.call_request(param: devisionstr!){ [self]
//
//            (res) in
//
//
//
//            let devisin : GetDivisionResponce  = Mapper<GetDivisionResponce>().map(JSONString: res)!
//
//            devisionRefName = devisin.data
//
//            var myArray: [String] = [ ]
//
//
//            devisionRefName.forEach {(arrType)  in
//                myArray.append((arrType.division_name))
//
//            }
//              print("frdfd",myArray)
//
//        dropDown.dataSource = myArray//4
//            dropDown.anchorView = dropDownView //5
//
//        dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
//
//        dropDown.direction = .bottom
//        DropDown.appearance().backgroundColor = UIColor.white
//            dropDown.show() //7
////        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
//
//
//            var idArray : [String] = []
//        devisionRefName.forEach {(arrType)  in
//            idArray.append((arrType.division_id))
//
//        }
//
//            dropDown.selectionAction = { [unowned self] (index:Int, item: String) in
//                    print("Selected item: \(item) at index: \(index)")
//
//                tv.isHidden = false
//                self.dropDownTextLabel.text = item
//
//
//                    let deparment = DepartmentModal()
//
//                    deparment.user_id = memberId
//
//                    deparment.college_id = collegeId
//
//                    deparment.div_id =  idArray[index]
//
//
//
//
//
//
//
//                    let deparmentstr = deparment.toJSONString()
//                    RepienceDeparmentRequest.call_request(param: deparmentstr!){ [self]
//
//                        (res) in
//
//
//
//                        let depart : RepienceDeparmentResponce  = Mapper<RepienceDeparmentResponce>().map(JSONString: res)!
//
//                        deparmentRefName = depart.data
//
//
//                        var addAryy: [String] = [ ]
//                        var itemAryy: [String] = [ ]
//
//
//                        depart.data .forEach {(arrType)  in
//                            addAryy.append((arrType.department_id))
//
//                        }
//
//                        depart.data .forEach {(arrType)  in
//                            itemAryy.append((arrType.department_name))
//
//                        }
//
//
//                    dropDown.dataSource = addAryy//4
//                        dropDown.anchorView = courseDropDownView //5
//
//                    dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
//
//                    dropDown.direction = .bottom
//                    DropDown.appearance().backgroundColor = UIColor.white
//                        dropDown.show() //7
//            //        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
//
//
////                        var idArray : [String] = []
////                    devisionRefName.forEach {(arrType)  in
////                        idArray.append((arrType.division_id))
////
////                    }
//
//                        dropDown.selectionAction = { [unowned self] (index:Int, item: String) in
//                            print("Selected item: \(item) at index: \(index)")
//
//                            tv.isHidden = false
//
//                            let course =  getCourseModal()
//
//                                       course.user_id = memberId
//                                       course.college_id = collegeId
//                                       course.dept_id = itemAryy[index]
//
//                                       print("rtyy",itemAryy[index])
//
//
//                                       let coursestr = course.toJSONString()
//                                       RepienceDeparmentRequest.call_request(param: coursestr!){ [self]
//
//                                           (res) in
//
//
//
//                                           let cour : getCourseResponce  = Mapper<getCourseResponce>().map(JSONString: res)!
//
//                                           courseRefName = cour.data
//
//
//                                           tv.delegate = self
//                                           tv.dataSource = self
//                                           tv.reloadData()
//
////                                           self.coursedropTxtLabel.text = item
//                                       }
//
//
//                            self.coursedropTxtLabel.text = item
//
//
//                        }
//
//                    }
//
//
//
//
//
//
//
//
//
//            }
//
//
//
//
//
//        }
//
//
//

    }
    @IBAction func dropDowVC(){
        
        
        let devisions = getDivisionModal()
        
        devisions.college_id = collegeId
        devisions.user_id =  memberId
        
        let devisionstr = devisions.toJSONString()


        DivisionRequest.call_request(param: devisionstr!){ [self]
            
            (res) in
            
            
            
            let devisin : GetDivisionResponce  = Mapper<GetDivisionResponce>().map(JSONString: res)!
            
            devisionRefName = devisin.data
            
            var myArray: [String] = [ ]
           
            
            devisionRefName.forEach {(arrType)  in
                myArray.append((arrType.division_name))
                
            }
              print("frdfd",myArray)
           
        dropDown.dataSource = myArray//4
            dropDown.anchorView = dropDownView //5
           
        dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
        
        dropDown.direction = .bottom
        DropDown.appearance().backgroundColor = UIColor.white
            dropDown.show() //7
//        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            
            
            var idArray : [String] = []
        devisionRefName.forEach {(arrType)  in
            idArray.append((arrType.division_id))
            
        }
           
            dropDown.selectionAction = { [unowned self] (index:Int, item: String) in
                    print("Selected item: \(item) at index: \(index)")
                
                tv.isHidden = false
                self.dropDownTextLabel.text = item
              
              
                    let deparment = DepartmentModal()
                    
                    deparment.user_id = memberId
                    
                    deparment.college_id = collegeId
                  
                    deparment.div_id =  idArray[index]
                
              
                        
                   
                   
                
                    
                    let deparmentstr = deparment.toJSONString()
                RepienceDeparmentRequest.call_request(param: deparmentstr!){ [self]
                    
                    (res) in
                    
                    
                    
                    let depart : RepienceDeparmentResponce  = Mapper<RepienceDeparmentResponce>().map(JSONString: res)!
                    
                    deparmentRefName = depart.data
                    
                    tv.dataSource = self
                    tv.delegate = self
                    tv.reloadData()
                    
                }

               
                
            }
            
            
            
            
            
        }
            
          
        
        
    }
    
    
    
    func devision(){
        
        
        let devisions = getDivisionModal()
        
        devisions.college_id = collegeId
        devisions.user_id =  memberId
        
        let devisionstr = devisions.toJSONString()


        DivisionRequest.call_request(param: devisionstr!){ [self]
            
            (res) in
            
            
            
            let devisin : GetDivisionResponce  = Mapper<GetDivisionResponce>().map(JSONString: res)!
            
            devisionRefName = devisin.data
            
            tv.delegate = self
            tv.dataSource = self
            tv.reloadData()
            
            
        }
        
        
    }
    
    
    
//    func deparment(){
//
//
//
//        let deparment = DepartmentModal()
//
//        deparment.user_id = memberId
//
//        deparment.college_id = collegeId
//        deparment.div_id = "5"
//
//        let deparmentstr = deparment.toJSONString()
//        RepienceDeparmentRequest.call_request(param: deparmentstr!){ [self]
//
//            (res) in
//
//
//
//            let depart : RepienceDeparmentResponce  = Mapper<RepienceDeparmentResponce>().map(JSONString: res)!
//
//            deparmentRefName = depart.data
//
//
//
//
//
//
//            tv.delegate = self
//            tv.dataSource = self
//            tv.reloadData()
//
//
//        }
//
//
//    }
    
    func Group(){
        
        
        
        let groups = GetGroupModal()
        
        groups.idcollege = collegeId
        let groupstr = groups.toJSONString()
        GetGroupRequest.call_request(param: groupstr!){ [self]
            
            (res) in
            
            
            
            let groupe : GetGroupResponce  = Mapper<GetGroupResponce>().map(JSONString: res)!
            
            groupRefName = groupe.data
            
            tv.isHidden = false
            tv.delegate = self
            tv.dataSource = self
            tv.reloadData()
            
            
        }
        
        
    }

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if devisionView.backgroundColor == UIColor(named: "selectColor"){
            return devisionRefName.count
        }
        
        else if departmentView.backgroundColor == UIColor(named: "selectColor"){
            
            print("departsdfgfd")
            return deparmentRefName.count
            
        }
        
        else if groupView.backgroundColor == UIColor(named: "selectColor"){
            
            return groupRefName.count
            
        }
        
        else if courseView.backgroundColor == UIColor(named: "selectColor"){
            
            
            return courseRefName.count
            
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath) as!
        
        SelectRespienceCellTableViewCell
        
        
        if devisionView.backgroundColor == UIColor(named: "selectColor"){
            
            let devi : getDivisonDataDetails = devisionRefName[indexPath.row]
            
            cell.nameLabel.text = devi.division_name
            
//            return cell
        }
        
        else if departmentView.backgroundColor == UIColor(named: "selectColor"){
            
            
            
            let depart : RepienceDeparmentDataDetails = deparmentRefName[indexPath.row]
            
            cell.nameLabel.text = depart.department_name
        }
        
        else if groupView.backgroundColor == UIColor(named: "selectColor"){
            
            let group : getGroupDataDetails = groupRefName[indexPath.row]
            cell.nameLabel.text = group.groupname
            
        }
        
        
        
        else if courseView.backgroundColor == UIColor(named: "selectColor"){
            
            let coursee : getCourseDataDetails = courseRefName[indexPath.row]
            cell.nameLabel.text = coursee.course_name
            
        }
        
return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         
        return 45
    }
    
    
    @IBAction func sendVc(){
        
        
        if entireCollegeCheckBoxView.isChecked == false{
//            SweetAlert().showAlert("Info", subTitle: "SomeThing Went Wrong ", style: .none, buttonTitle: "ok")
            
            if (staffCheckBoxView.isChecked == false) && (parentsCheckBoxView.isChecked == false) && (studentCheckBoxView.isChecked == false) {
                
                
                
                SweetAlert().showAlert("Info", subTitle: "SomeThing Went Wrong ", style: .none, buttonTitle: "ok")
                
            }
            
            else {
                
                let entier = EntierCollegeModal()
                
                entier.collegeid = collegeId
                entier.staffid = memberId
                entier.filetype = "1"
                entier.callertype = priority
                entier.isparent =  parentsCheckBoxView.isChecked
                entier.isstaff = staffCheckBoxView.isChecked
                entier.isstudent = studentCheckBoxView.isChecked
                print("edfss",staffCheckBoxView.isChecked)
                entier.messagecontent = titlesTextField
                print("see",titlesTextField)
                entier.description = discreptionss
                
                
                let entierstr = entier.toJSONString()
                EntierCollegeRequest.call_request(param: entierstr!){ [self]
                    
                    (res) in
                    
                    
                    
                    let depart : EntierCollegeResponce  = Mapper<EntierCollegeResponce>().map(JSONString: res)!
                    
                    entierRefName = depart.data
                    
                    
                    if depart.Status == 1{
                        
                        
                        
                        SweetAlert().showAlert("Info", subTitle: depart.Message, style: .none, buttonTitle: "ok")
                        
                        
                    }
                    
                    tv.dataSource = self
                    tv.delegate = self
                    tv.reloadData()
                    
                    
                }
            
                
                
            }
            
        }
        
        
       
        
        
        
        else   {
            
            
            let entier = EntierCollegeModal()
            
            entier.collegeid = collegeId
            entier.staffid = memberId
            entier.filetype = "1"
            entier.callertype = priority
            entier.isparent =  parentsCheckBoxView.isChecked
            entier.isstaff = staffCheckBoxView.isChecked
            entier.isstudent = studentCheckBoxView.isChecked
            print("edfss",staffCheckBoxView.isChecked)
            entier.messagecontent = titlesTextField
            print("see",titlesTextField)
            entier.description = discreptionss
            
            
            let entierstr = entier.toJSONString()
            EntierCollegeRequest.call_request(param: entierstr!){ [self]
                
                (res) in
                
                
                
                let depart : EntierCollegeResponce  = Mapper<EntierCollegeResponce>().map(JSONString: res)!
                
                entierRefName = depart.data
                
                
                tv.dataSource = self
                tv.delegate = self
                tv.reloadData()
                
                
            }
        }
        
    }
    
    
    @IBAction func entireCollegeVc() {
        
        
        
        
        
        if entireCollegeCheckBoxView.isSelected == true{
            //
                        entireCollegeCheckBoxView.isSelected = false
            
            //            devisionView.isUserInteractionEnabled = false
            //            departmentView.isUserInteractionEnabled = false
            //            courseView.isUserInteractionEnabled = false
            //
            //                            devisionTabel.textColor = UIColor(named: "selectColor")
//            departmentLabel.textColor = UIColor(named: "selectColor")
            //                            courseLabel.textColor = UIColor(named: "selectColor")
            //                            yourClassLabel.textColor = UIColor(named: "selectColor")
            //                            groupLabel.textColor = UIColor(named: "selectColor")
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            print("UnMark")
            
            
            
        }else {
            
            entireCollegeCheckBoxView.isSelected = false
           
            
            devisionView.isUserInteractionEnabled = true
            departmentView.isUserInteractionEnabled = true
            courseView.isUserInteractionEnabled = true
            yourClassesView.isUserInteractionEnabled = true
            groupView.isUserInteractionEnabled = true
            devisionView.backgroundColor = UIColor.white
            departmentView.backgroundColor = UIColor.white
            
            courseView.backgroundColor = UIColor.white
            yourClassesView.backgroundColor = UIColor.white
            groupView.backgroundColor = UIColor.white
            departmentLabel.textColor = UIColor(named: "clickView")
            devisionTabel.textColor = UIColor(named: "clickView")
            courseLabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            groupLabel.textColor = UIColor(named: "clickView")
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("tickMark")
            
        }
        
    }
    
    
    @IBAction func devisionVc() {
        
        
        
        
        
        if entireCollegeCheckBoxView.isSelected == false {
            topIdentificationLabel.text = "Division"
            dropDownView.isHidden = true
          
            tv.isHidden = false
            devisionView.isUserInteractionEnabled = true
            devisionView.backgroundColor = UIColor(named: "selectColor")
            devisionTabel.textColor = UIColor.white
            departmentLabel.textColor = UIColor(named: "clickView")
            courseLabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            groupLabel.textColor = UIColor(named: "clickView")
            departmentView.backgroundColor = UIColor.white
            courseView.backgroundColor = UIColor.white
            yourClassesView.backgroundColor = UIColor.white
            groupView.backgroundColor = UIColor.white
            //                departmentView.isUserInteractionEnabled = true
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
//            print("devision")
            
            devision()
            
            
            
            
            
            
            
        }else {
            
            devisionView.isUserInteractionEnabled = false
            
            
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("clickedOff")
            
        }
        
        
        
        
    }
    
    
    
    
    @IBAction func departmentVc (){
        
        
        
        if entireCollegeCheckBoxView.isSelected == false{
            topIdentificationLabel.text = "Deparment"
            dropDownTextLabel.text = "--SelectDivision--"
            dropDownView.isHidden = false
            tvTopConstain.constant = 0
            tv.isHidden = true
            departmentView.isUserInteractionEnabled = true
            departmentView.backgroundColor = UIColor(named: "selectColor")
            courseLabel.textColor = UIColor(named: "clickView")
            devisionTabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            groupLabel.textColor = UIColor(named: "clickView")
            devisionView.backgroundColor = UIColor.white
            courseView.backgroundColor = UIColor.white
            departmentLabel.textColor = UIColor.white
            yourClassesView.backgroundColor = UIColor.white
            groupView.backgroundColor = UIColor.white
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
     
            
            
        }else {
            
            departmentView.isUserInteractionEnabled = false
           
            
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("clickedOff")
            
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
    @IBAction func course(){
        
        
        if entireCollegeCheckBoxView.isSelected == false {
            //
            
            dropDownView.isHidden = false
            courseView.isUserInteractionEnabled = true
            courseView.backgroundColor = UIColor(named: "selectColor")
            courseLabel.textColor = UIColor.white
            departmentLabel.textColor = UIColor(named: "clickView")
            devisionTabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            courseLabel.textColor = UIColor.white
            groupLabel.textColor = UIColor(named: "clickView")
            
            devisionView.backgroundColor = UIColor.white
            departmentView.backgroundColor = UIColor.white
            yourClassesView.backgroundColor = UIColor.white
            groupView.backgroundColor = UIColor.white
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            print("courseclickedd")
            
            
            
        }else {
            
            courseView.isUserInteractionEnabled = false
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("clickedOff")
            
        }
        
        
        
        
        
        
        
        
    }
    
    
    
    @IBAction func yourClassFunction () {
        
        if entireCollegeCheckBoxView.isSelected == false {
            
            yourClassesView.isUserInteractionEnabled = true
            
            yourClassesView.backgroundColor = UIColor(named: "selectColor")
            //            yourClassLabel.textColor = UIColor.white
            departmentLabel.textColor = UIColor(named: "clickView")
            courseLabel.textColor = UIColor(named: "clickView")
            devisionTabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            groupLabel.textColor = UIColor(named: "clickView")
            courseView.backgroundColor = UIColor.white
            yourClassLabel.textColor = UIColor.white
            devisionView.backgroundColor = UIColor.white
            departmentView.backgroundColor = UIColor.white
            groupView.backgroundColor = UIColor.white
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            print("yourClassFucntion")
            
            
            
        }else {
            
            yourClassesView.isUserInteractionEnabled = false
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("clickedOff")
            
        }
      
    }
    
    
    
    @IBAction func group () {
        
        
        if entireCollegeCheckBoxView.isSelected == false {
            
            groupView.isUserInteractionEnabled = true
            
            topIdentificationLabel.text = "Group"
            
            dropDownView.isHidden = true
            groupView.backgroundColor = UIColor(named: "selectColor")
            //            groupLabel.textColor = UIColor.white
            departmentLabel.textColor = UIColor(named: "clickView")
            courseLabel.textColor = UIColor(named: "clickView")
            devisionTabel.textColor = UIColor(named: "clickView")
            yourClassLabel.textColor = UIColor(named: "clickView")
            
            yourClassesView.backgroundColor = UIColor.white
            courseView.backgroundColor = UIColor.white
            groupLabel.textColor = UIColor.white
            
            devisionView.backgroundColor = UIColor.white
            departmentView.backgroundColor = UIColor.white
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            print("group")
            
            Group()
            
        }else {
            
            groupView.isUserInteractionEnabled = false
            
            
            entireCollegeCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
            
            
            
            print("clickedOff")
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func StudentCheckBoxVc(){
        
        
        if studentCheckBoxView.isChecked == true{
            
            
//            print("styy",staffCheckBoxView.isChecked)
            studentCheckBoxView.isChecked = false
            print("okkkdsdxs",studentCheckBoxView.isChecked)
//            staffCheckBoxView.isChecked = false
//            parentsCheckBoxView.isChecked = false
//
            
            
            studentCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            
            
        }
        //
        else if studentCheckBoxView.isChecked == false{
            
            
            studentCheckBoxView.isChecked = true
            print("okkkd",studentCheckBoxView.isChecked)
            studentCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
//            studentCheckBoxView.isChecked = true
//            staffCheckBoxView.isChecked = false
//            parentsCheckBoxView.isChecked = false
//
            
        }
        
        
        
    }
    
    
    
    @IBAction func parentCheckBoxVc(){
        
        
        
        if parentsCheckBoxView.isChecked == true{
//
//            parentsCheckBoxView.isChecked = true
//            studentCheckBoxView.isChecked = false
//            staffCheckBoxView.isChecked = false
//
            parentsCheckBoxView.isChecked = false
            parentsCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
//
            
            
            print("UNCheck")
            
            
        } else if parentsCheckBoxView.isChecked == false  {
            
            parentsCheckBoxView.isChecked = true
            parentsCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
//
//            parentsCheckBoxView.isChecked = true
//            staffCheckBoxView.isChecked =  false
//            studentCheckBoxView.isChecked = false
//            print("Check")
            
        }
        
        
        
        
    }
    
    
    
    @IBAction func staffCheckBoxVC(){
        
        
        
        
        if staffCheckBoxView.isChecked == true {
            
            staffCheckBoxView.isChecked = false
            staffCheckBoxView.setImage(UIImage.init(named: "checkboxs"), for: .normal)
            
            
        } else if  staffCheckBoxView.isChecked == false {
            
            staffCheckBoxView.isChecked = true
            staffCheckBoxView.setImage(UIImage.init(named: "done"), for: .normal)
     }
        
        
        
    }
    
    
    
    
    
    @IBAction func CancelVc(){
        
        
        dismiss(animated: true)
        
        
        
    }
    
    
    
    
    
}
