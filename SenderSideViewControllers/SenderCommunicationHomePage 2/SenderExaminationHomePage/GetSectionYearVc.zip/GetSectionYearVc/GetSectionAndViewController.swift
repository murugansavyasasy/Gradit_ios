//
//  GetSectionAndViewController.swift
//  Vs_GradItCollege
//
//  Created by MACBOOKPRO on 26/03/23.
//

import UIKit
import ObjectMapper
import KRProgressHUD
import DropDown

class GetSectionAndViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate, UIGestureRecognizerDelegate,UITextViewDelegate {
    
    @IBOutlet weak var tapBarView: UIView!
    
    @IBOutlet weak var redirectLoginView: UIViewX!
    
    @IBOutlet weak var Tv: UITableView!
    
    
    @IBOutlet weak var datePickerView: UIView!
    @IBOutlet weak var datePickerSet: UIDatePicker!
    @IBOutlet weak var confirmView: UIView!
    
    
    
    @IBOutlet weak var TopTv: UITableView!
    @IBOutlet weak var nodataView: UIView!
    
    @IBOutlet weak var noDataLabel: UILabel!
    
    
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var topLabels: UILabel!
    
    
    @IBOutlet weak var profileView: UIView!
    
    @IBOutlet weak var viewTap: UIView!
    
    @IBOutlet weak var clgLogoImg: UIImageView!
    @IBOutlet weak var topMessageLabel: UILabel!
    
    
    
    @IBOutlet weak var smallImg: UIImageView!
    @IBOutlet weak var bigImg: UIImageView!
    @IBOutlet weak var adView: UIView!
    
    @IBOutlet weak var changeRolesView: UIView!
    
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var refreshView: UIView!
    
    @IBOutlet weak var sideMenuView: UIView!
    
    
    @IBOutlet weak var termsAndConditionView: UIView!
    @IBOutlet weak var faqView: UIView!
    
    @IBOutlet weak var privacyPolicyView: UIView!
    
    
    @IBOutlet weak var changePasswordView: UIView!
    @IBOutlet weak var helpView: UIView!
    
    
    
    var didSeleId : Int!
    var closedidSeleId : Int!
    
    
    
    var SubjectdetailssujectData : [Subjectdetails] = []
    var sujectData : [Subjectdetails] = []
    
    var examViewRefName : [examviewDataDetails] = []
    var indexPathss : Int!
    var indexPat : [Int] = []
    var indexPathsections : Int!
    
    
    var getSectionName : String!
    var getHeaderId : String!
    
    var selectedList1 : [String:[String]] = [:]
    var sunjectNewId : String!
    var selectedList = [[String]]()
    var subjectProperId  = ""
    var identifiers = "GetSectionYearTableViewCell"
    var identifier2 = "GetSectionYearHeaderFooterView"
    var reloadSections: ((_ section: Int) -> Void)?
    var getSection : [getSubjectWiseDataDetails] = []
    var GetSectionNmeRef : [getSectionDatasDetails] = []
    var examAddRef : [Sectiondetails] = []
    var examSubRef : [Datass] = []
    var sectionRefss : [Subjectdetails] = []
    
    var ExameSection : [examviewDataDetails] = [] // this for edit list variabel
    
    
    //    var subRefName : [subjectDatasDetails] = []
    
    var aryObject : [String] = []
    var userId : String!
    var appId : String!
    var display_date : String!
    
    var url_date : String!
    var semsterID : String!
    var selectedCell : IndexPath?
    var colgId : String!
    
    var exameName : String!
    
    var startDate : String!
    
    var endDate : String!
    
    var clgDepartId : String!
    
    var sectionId : String!
    
    var examHeaderId : String!
    
    var sunjectIds : [String] = []
    var sectionIds : [String] = []
    var model = [String]()
    var sylubus : [String] = []
    var venu : [String]  = []
    var nameString : String!
    
    var subjectsssss : String!
    var venusss : [String] = []
    var sylubasss : [String] = []
    var datess : [String] = []
    var productTags : [String : [String]] = [:]
    var venstr : String!
    var sylubstr : String!
    var indexss : [Int] = []
    
    
    var GetsectioId : Int! = 1
    var loginDatas : [datalogin]!
    var logindataprinci :[datalogin]!
    
    var MobileNumber : String!
    
    var password : String!
    
    var priority : String!
    
    var  colgImg : String!
    
    var addImageBackGroundurl : String!
    
    var smallImageUrl : String!
    var seci  = ""
    var imageWebUrl : String!
    var hiddenSections = Set<Int>()
    let dropDown = DropDown()
    var saves : [SubjectDetailsRef] = []
    var clgsection : [SectiondetailRef] = []
    
    var examCre : [exameMainDetail] = []
    
    var examEditresp : [exameEditMainDetail] = [] // important
    var examEditsModalApi : [EditSubjectDetailsRef] = [] // important
    var sectiondetails: [EditSectiondetailRef] = [] // important
    var saveEdit : [EditSubjectDetailsRef] = [] // important
    var selectedIndex = -1
    
    var EditId : String!
    
    var sectionNameForEdit : String!
    
//    var venuTextfld : UITextField!
    
    var sectionIdForEdit : String! // this for exam edit Section Id
    var examHeaderIdForEdit : String! // this for exam edit examHeade Id
    
    var ExamEditSubjectId : String!
    var StartDateEdit : String!
    var EndDateEdit : String!
    var ExameNameEdit : String!
    var isclosaps = false
    
    var sectionsForCompar : String!
    
    var saveButtonId : String! // important
    override func viewDidLoad() {
        super.viewDidLoad()
        print("sectiondetails",sectiondetails.count)
        print("examEditsModalApi1234565432123456",examEditsModalApi.count)
        print("examEditresp",examEditresp.count)
        print("clgDepartId",clgDepartId)
        print("sectionIdss",sectionId)
        
        overrideUserInterfaceStyle = .light
        print("ExameSection",EditId)
        
//        print("1234566666",saveEdit.count)
//        saveEdit.append(contentsOf: examEditsModalApi )
//
//        print("fhfgjggbvvjkvjk",saveEdit.count)
        
        
        //        for i in clgsection{
        //
        
        datePickerSet.isHidden = true
        datePickerView.isHidden = true
        //        }
      
      
        
       
        
        
        
        
      
        
//        bigImg.sd_setImage(with: URL(string: addImageBackGroundurl), placeholderImage: UIImage(named: "ic_white"))
//        smallImg.sd_setImage(with: URL(string: smallImageUrl ), placeholderImage: UIImage(named: "ic_white"))
//
        nodataView.isHidden = true
        noDataLabel.isHidden = true
        sideMenuView.isHidden = true
        
        let defaults = UserDefaults.standard
        
        
        priority  =  defaults.string(forKey: DefaultsKeys.priority)
        userId = defaults.string(forKey: DefaultsKeys.memberid)
        
        colgId = defaults.string(forKey: DefaultsKeys.collegeid)
        
        MobileNumber = defaults.string(forKey: DefaultsKeys.mobileNumber)
        password = defaults.string(forKey: DefaultsKeys.Password)
        
        colgImg = defaults.string(forKey: DefaultsKeys.colglogo)
        clgLogoImg.sd_setImage(with: URL(string:  colgImg), placeholderImage: UIImage(named: "person.fill"))
        
        topMessageLabel.text = defaults.string(forKey: DefaultsKeys.memberName)
        
//        venuTextfld.delegate = self
        
        
        if priority == "p1"{
            
            topLabels.text = "Principal"
            tapBarView.backgroundColor = UIColor(named: "Principal")
            view.backgroundColor = UIColor(named: "Principal")
        }
        
        else if priority == "p4"{
            
            topLabels.text = "Student"
            
        }
        
        else if priority == "p2" {
            
            tapBarView.backgroundColor = UIColor(named: "Teaching Staff")
            topLabels.text = "Hod"
            
        }
        
        else if priority == "p5"{
            
            
            topLabels.text = "Father"
            
            
            
        }
        
        else if  priority == "p3"{
            tapBarView.backgroundColor = UIColor(named: "Teaching Staff")
            topLabels.text = "Teacher"
            
            
        }
        
        priority = defaults.string(forKey: DefaultsKeys.priority)
        GetSectionAndYear()
        
        let rowNib = UINib(nibName: identifiers, bundle: nil)
        Tv.register(rowNib, forCellReuseIdentifier: identifiers)
        
        let rownib2 = UINib(nibName: identifier2, bundle: nil)
        Tv.register(rownib2, forHeaderFooterViewReuseIdentifier: identifier2)
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(adLoad))
        
        bigImg.isUserInteractionEnabled = true
        bigImg.addGestureRecognizer(singleTap)
        
        let confirm = UITapGestureRecognizer(target: self, action: #selector(ConfirmVc))
        confirmView.addGestureRecognizer(confirm)
        
        // tap Bar UiTapGuster.
        
        let loginRediectGesture = UITapGestureRecognizer(target: self, action: #selector(priorityVc))
        redirectLoginView.addGestureRecognizer(loginRediectGesture)
        
        
        
        let changeRolesGesture = UITapGestureRecognizer(target: self, action: #selector(priorityVc))
        changeRolesView.addGestureRecognizer(changeRolesGesture)
        
        
        let logoutGesture = UITapGestureRecognizer(target: self, action: #selector(logoutPressed))
        loginView.addGestureRecognizer(logoutGesture)
        
        
        
        
        
        let menuGestureHide = UITapGestureRecognizer(target: self, action: #selector(menu))
        viewTap.addGestureRecognizer(menuGestureHide)
        
        let refreshGesture = UITapGestureRecognizer(target: self, action: #selector(refreshVc))
        refreshView.addGestureRecognizer(refreshGesture)
        
        
        let faqGesture = UITapGestureRecognizer(target: self, action: #selector(faqRedirect))
        faqView.addGestureRecognizer(faqGesture)
        
        
        let helpGesture = UITapGestureRecognizer(target: self, action: #selector(helpRedirect))
        helpView.addGestureRecognizer(helpGesture)
        //
        
        let privacyPolicyGesture = UITapGestureRecognizer(target: self, action: #selector(privacyPolicyRedirect))
        privacyPolicyView.addGestureRecognizer(privacyPolicyGesture)
        
        let termsAndConditionGesture = UITapGestureRecognizer(target: self, action: #selector(termsAndCondition))
        termsAndConditionView.addGestureRecognizer(termsAndConditionGesture)
        
        
        let chagePassword = UITapGestureRecognizer(target: self, action: #selector(changePassowrdVC))
        changePasswordView.addGestureRecognizer(chagePassword)
        
        let toplabelclick = UITapGestureRecognizer(target: self, action: #selector(priorityVc))
        topLabels.addGestureRecognizer(toplabelclick)
        
        
        
    }
    
    
    
    @IBAction func adLoad(){
        
        
        
        let vc = TotalAddLoadPageViewController(nibName: nil, bundle: nil)
        
        vc.AddWebUrl = imageWebUrl
        
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true,completion: nil)
        
        
    }
    
    @IBAction func ConfirmVc(){
        
        
        createExam()
        
        
        
        
        
        
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        
        if EditId == "1"{
            
            
            return getSection.count
            
        
        }
//
        else {
//
            return getSection.count
            
        }
        
        
        
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        print("weryuiopoiuytrewq")
        return 60
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        
      
        let cell1 = tableView.dequeueReusableHeaderFooterView(withIdentifier: identifier2) as!
        GetSectionYearHeaderFooterView
        
        
        
        
//        if EditId == "1"{
            
//            let examsec : examViewSubjectDataDetails =
            
            
        
        
        
        
        
//            getSectionName = sectionNameForEdit
////            print("examsec",examsec)
//            if getSection[section].sectionname == examViewRefName[section].clgsectionname {
//
//                getHeaderId = "1"
//                print("getSection[indexPath.section].sectionname",getSection[section].sectionname)
//                if   getSectionName  ==  getSection[section].sectionname {
//                    let cell = tableView.dequeueReusableCell(withIdentifier: identifiers) as!
//
//                    GetSectionYearTableViewCell
//
//                    cell.SubjectLabel.text = String( getSection[section].subjectdetails[section].subjectname)
//                    cell.SubjectLabel.isHidden = false
//
//                    cell.overallView.isHidden = false
//                    cell.sectionDropDownLabel.text = ExameSection[section].examsession
//                    cell.calanderDateLabel.text = ExameSection[section].examdate
//                    cell.sylubasTextView.text = ExameSection[section].examsyllabus
//                    cell.venuLabel.text = ExameSection[section].examvenue
////                    print("examsec.examsession",examsec.examsession)
////                    print("examsec.examdate",examsec.examdate)
//                    cell.sylubasTextView.textColor = UIColor.black
//                    cell.sylubasTextView.font = UIFont(name: "verdana", size: 11.0)
//
//                    cell.subjectCheckBox.isUserInteractionEnabled = false
//                    cell.cellSubjectView.isHidden = false
//                    cell.subjectCheckBox.setImage(UIImage.init(named: "verified"), for: .normal)
//
//
//                }else{
//                    let cell1 = tableView.dequeueReusableCell(withIdentifier: identifiers) as!
//
//                    GetSectionYearTableViewCell
//                    cell1.subjectCheckBox.isUserInteractionEnabled = false
//                    cell1.overallView.isHidden = true
//
//
//
//                }
//
//            }
//
            
        
        
        
        
        
        
//        }
        
        
        
//        else {
            
        
       
        
        if EditId == "1"{
            
//            if getSection[section].sectionname == examViewRefName[section].clgsectionname
//            {
            
            
//            headerTop.constant
            
            print("ifff",cell1.headerTop.constant)
                let sectionName : getSubjectWiseDataDetails = getSection[section]
                
               
                cell1.sectionLabl.text = sectionName.sectionname
                
            print("sectionEditttt")
            
          
            if   sectionIdForEdit  ==  getSection[section].sectionid {
                    
                if section == 0 {
                    cell1.headerTop.constant = 0
                    cell1.headerHeight.constant = 36
                    print("cell1.",cell1.headerHeight.constant)
                }else {
                    GetsectioId = 1
//                    Tv.contentView.frame = 10
//                    Tv.rowHeight = 800.0
//                    cell.
                    
//                    var cell = Tv.cellForRowAtIndexPath(section)
//                          cell.frame.height = 10
//                    cell1.headerTop.constant = 50
                    cell1.headerHeight.constant = 36
                    print("cell1.",cell1.headerHeight.constant)
                }
              
                
//                cell1.headerHeight.constant = 36
                
                    //                 cell1.FullViewClick.backgroundColor = .blue
                    cell1.sectionCheckBox.isUserInteractionEnabled = false
                    
                    
                    cell1.sectionCheckBox.setImage(UIImage.init(named: "verified"), for: .normal)
                
                let vc = EditSectiondetailRef()
                
                vc.clgsectionid = sectionIdForEdit
                
                //           print("selectedList",selectedList)
                print(" vc.clgsectionid", vc.clgsectionid)
                
                
                sectiondetails.append(vc)
                
                    
//                    let subjectCheck = SelectSubject(target: self, action: #selector(subjectCheckBoxvc))
//                    subjectCheck.checkBoxx = cell1.sectionCheckBox
//                    subjectCheck.index = IndexPath(row: 0, section: section)
//                    subjectCheck.sectionID = sectionName.sectionid
//                    seci = sectionName.sectionid
//
//                    cell1.sectionCheckBox.addGestureRecognizer(subjectCheck)
                    
                    
//
                }
            
            else{
//                    //                 cell1.FullViewClick.backgroundColor = .red
                    cell1.sectionCheckBox.isUserInteractionEnabled = false
                cell1.FullViewClick.backgroundColor = UIColor(named: "lineView")
                
//                else{
                    cell1.headerTop.constant = -60
//                    self.Tv.rowHeight = 14.0
                    cell1.headerHeight.constant = 30
                    cell1.FullViewClick.layoutIfNeeded()
                    print("cell1.headerHeight.constan",cell1.headerHeight.constant)
//                }
                print("elsee",cell1.headerTop.constant)
                
                cell1.headerTop.constant = 20
//                cell1.headerHeight.constant = 36
                    cell1.sectionCheckBox.setImage(UIImage.init(named: "Verify"), for: .normal)
//
                }
                
               
                
//            }
//
//            else{
//
//                let sectionName : getSubjectWiseDataDetails = getSection[section]
//
//
//                cell1.sectionLabl.text = sectionName.sectionname
//
//                getSectionName = sectionName.sectionname
//
//
//
//
//                let subjectCheck = SelectSubject(target: self, action: #selector(subjectCheckBoxvc))
//                subjectCheck.checkBoxx = cell1.sectionCheckBox
//                subjectCheck.index = IndexPath(row: 0, section: section)
//                subjectCheck.sectionID = sectionName.sectionid
//                seci = sectionName.sectionid
//
//                cell1.sectionCheckBox.addGestureRecognizer(subjectCheck)
//
//
//
//            }
//
        }
        
        
        else {
            
            let sectionName : getSubjectWiseDataDetails = getSection[section]
            
            cell1.sectionLabl.text = sectionName.sectionname
            
            
            getSectionName = sectionName.sectionname
            
            
            
            
            let subjectCheck = SelectSubject(target: self, action: #selector(subjectCheckBoxvc))
            subjectCheck.checkBoxx = cell1.sectionCheckBox
            subjectCheck.index = IndexPath(row: 0, section: section)
            subjectCheck.sectionID = sectionName.sectionid
            seci = sectionName.sectionid
            
            cell1.sectionCheckBox.addGestureRecognizer(subjectCheck)
            
        }
            
            
//        }
        return cell1
    }
    
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
    }
    
    //
        @objc private func hideSection(sender: HeaderTapGesture) {
            var index = IndexPath(row: 0, section: sender.tagss)
    
          let section = sender.tagss
            print("senderTagssssss",sender.tagss)
            func indexPathsForSection() -> [IndexPath] {
                var indexPaths = [IndexPath]()
    
                print("sectionerettretrfds",section)
                for row in 0..<self.getSection.count {
                    indexPaths.append(IndexPath(row: row,
                                                section: section!))
    
                    print("indexxxxdsssds",indexPaths)
                }
    
                return indexPaths
            }
    
            if self.hiddenSections.contains(section!) {
                self.hiddenSections.remove(section!)
                self.Tv.insertRows(at: indexPathsForSection(),
                                          with: .fade)
            } else {
                self.hiddenSections.insert(section!)
                self.Tv.deleteRows(at: indexPathsForSection(),
                                          with: .fade)
            }
        }
    @IBAction func subjectCheckBoxvc(gesture : SelectSubject ){
        
        
        if EditId == "1"{
            
            if gesture.checkBoxx.isChecked == true{
                
                
                //        print("fghghgfhghjghj")
                
                gesture.checkBoxx.setImage(UIImage.init(named: "Verify"), for: .normal)
                
                //            sectionIds.removeLast()
                gesture.checkBoxx.isChecked = false
                
                
            }
            
            
            else {
                
                
                
                //            print("ooooooooooooo")
                gesture.checkBoxx.setImage(UIImage.init(named: "verified"), for: .normal)
                
                //            print("jklll",gesture.index)
                
                selectedList1.append(["sectioID" : [gesture.sectionID]])
                selectedList.append([gesture.sectionID])
                
                //
                
                
                
                let vc = EditSectiondetailRef()
                
                vc.clgsectionid = gesture.sectionID
                
                //           print("selectedList",selectedList)
                print(" vc.clgsectionid", vc.clgsectionid)
                
                
                sectiondetails.append(vc)
                
                sectionIds.append(gesture.sectionID)
                
                nameString =  gesture.sectionID
                
                
                
                gesture.checkBoxx.isChecked = true
            }
            
            
        }
        
        
        
        
        else {
            
            
            if gesture.checkBoxx.isChecked == true{
                
                
                //        print("fghghgfhghjghj")
                
                gesture.checkBoxx.setImage(UIImage.init(named: "Verify"), for: .normal)
                
                //            sectionIds.removeLast()
                gesture.checkBoxx.isChecked = false
                
                
            }
            
            
            else {
                
                
                
                //            print("ooooooooooooo")
                gesture.checkBoxx.setImage(UIImage.init(named: "verified"), for: .normal)
                
                //            print("jklll",gesture.index)
                
                selectedList1.append(["sectioID" : [gesture.sectionID]])
                selectedList.append([gesture.sectionID])
                
                //
                
                
                
                let vc = SectiondetailRef()
                
                vc.clgsectionid = gesture.sectionID
                
                //           print("selectedList",selectedList)
                print(" vc.clgsectionid", vc.clgsectionid)
                
                
                clgsection.append(vc)
                
                sectionIds.append(gesture.sectionID)
                
                nameString =  gesture.sectionID
                
                
                
                gesture.checkBoxx.isChecked = true
            }
            
            
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if self.hiddenSections.contains(section) {
            return 0
        }
        
        
        
        
        
//
////
//        else if EditId == "1"{
//print("ExameSection.count",ExameSection.count)
//            return getSection[section].subjectdetails.count

//        }
        
        // 2
        //
               return self.getSection.count
//        return self.getSection[section].subjectdetails.count
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifiers, for: indexPath) as!
        
        GetSectionYearTableViewCell
        
        
  
        
        
        
        print("getHeaderIdSecond")
        
        //        cell.selectImg.image = UIImage(named: "checkboxs" )
        
//        if EditId == "1"{
//
//
            
            
            if let selectedCell = selectedCell, selectedCell == indexPath {
                
                
                
                cell.venuView.isHidden = false
                
                
                //            cell.subjectCheckBox.isChecked = true
            }
            
            else{
                
                cell.venuView.isHidden = true
                //            cell.subjectCheckBox.isChecked = false
                
                
            }
        
      
        
        
        
        
        
        
        
            
//            let examsec : examViewSubjectDataDetails = ExameSection[indexPath.row]
//
//
//            getSectionName = sectionNameForEdit
////            getSection[indexPath.section].sectionname
//            print("examsec",examsec)
//
//
//
//            if getSection[indexPath.section].sectionname == examViewRefName[indexPath.section].clgsectionname {
//
//                    getHeaderId = "1"
//                print("getSectionName",getSectionName)
//                print("getSection[indexPath.section].sectionname",getSection[indexPath.section].sectionname)
//                if   getSectionName  ==  getSection[indexPath.section].sectionname {
//                    cell.SubjectLabel.text = String( getSection[indexPath.section].subjectdetails[indexPath.row].subjectname)
//                    cell.SubjectLabel.isHidden = false
//
//                    cell.overallView.isHidden = false
//                    cell.sectionDropDownLabel.text = examsec.examsession
//                    cell.calanderDateLabel.text = examsec.examdate
//                    cell.sylubasTextView.text = examsec.examsubjectname
//                    print("examsec.examsession",examsec.examsession)
//                    print("examsec.examdate",examsec.examdate)
//                    cell.sylubasTextView.textColor = UIColor.black
//                    cell.sylubasTextView.font = UIFont(name: "verdana", size: 11.0)
//                    cell.subjectCheckBox.isUserInteractionEnabled = false
//
//                    cell.cellSubjectView.isHidden = false
//                    cell.subjectCheckBox.setImage(UIImage.init(named: "verified"), for: .normal)
//                    cell.subjectCheckBox.isUserInteractionEnabled = false
////
//                }else{
//                    cell.overallView.isHidden = true
//                    cell.cellSubjectView.isHidden = true
//                    cell.SubjectLabel.isHidden = false
//                    cell.subjectCheckBox.setImage(UIImage.init(named: "Verify"), for: .normal)
////
////
//                    cell.subjectCheckBox.isUserInteractionEnabled = true
//                   }
//
//
//
////
//            }
//
//
//
//
//
//
//
//            print("sylubasTextView",examsec.examsubjectname)
//
//
//
//
//
////        }
////        else {
////
//
//            print("closeddd",didSeleId)
//
//            print( "cell.venuView.isHidden = false", cell.venuLabel.text)
//
//            if let selectedCell = selectedCell, selectedCell == indexPath {
//
//
//
//                cell.venuView.isHidden = false
//
//            }
//
//            else{
//
//                cell.venuView.isHidden = true
//
//            }
//
        
        
        print("sectionIdForEdit",sectionIdForEdit)
        print("sectionsForCompar",sectionsForCompar)
        
        
        sectionsForCompar = String( getSection[indexPath.section].sectionid)
        
      
        if EditId == "1"{
            
            
  if  sectionIdForEdit == sectionsForCompar {
            
      cell.isUserInteractionEnabled = true
            cell.overAllView.isHidden = false
    
            
                
            cell.SubjectLabel.text = String( getSection[indexPath.section].subjectdetails[indexPath.row].subjectname)
            
            
//            if String( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
            for ik in 0..<(examEditsModalApi.count){
                
              
                    
                    ExamEditSubjectId = String(getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                if examEditsModalApi[ik].examsubjectid == ExamEditSubjectId{
                    
                    print("examEditsModalApi[ik].examsubjectid",examEditsModalApi[ik].examsubjectid == ExamEditSubjectId)
//                    let examsec : examViewSubjectDataDetails = ExameSection[indexPath.row]
                    cell.venuLabel.text = examEditsModalApi[ik].examvenue
                    cell.sylubasTextView.text = examEditsModalApi[ik].examsyllabus
                    cell.calanderDateLabel.text = examEditsModalApi[ik].examdate
                    cell.sectionDropDownLabel.text = examEditsModalApi[ik].examsession
                        
                        cell.subjectCheckBox.setImage(UIImage.init(named: "verified"), for: .normal)
                    
                    let vc = NoonCell(target: self, action: #selector(NoonVc))
                    vc.noonClick = cell.sectionDropDownView
                    vc.noonLabel = cell.sectionDropDownLabel
                    cell.sectionDropDownView.addGestureRecognizer(vc)
                    
                    let calnder = UITapGestureRecognizer(target: self, action: #selector(CalanderVc))
                    cell.clanderView.addGestureRecognizer(calnder)
                    
                    
                    
                    }
                
                
                else {
                    
                    
                    cell.sectionDropDownLabel.text = "Session"
                    cell.calanderDateLabel.text = "DD/MM/YY"
                    
                    cell.sylubasTextView.text = "Syllabus"
                    cell.sylubasTextView.textColor = UIColor.black
                    cell.sylubasTextView.font = UIFont(name: "verdana", size: 11.0)
                    
                    let vc = NoonCell(target: self, action: #selector(NoonVc))
                    vc.noonClick = cell.sectionDropDownView
                    vc.noonLabel = cell.sectionDropDownLabel
                    cell.sectionDropDownView.addGestureRecognizer(vc)
                    
                    
                    cell.venuLabel.returnKeyType = .done
                    cell.venuLabel.delegate = self
                    cell.sylubasTextView.returnKeyType = .done
                    cell.sylubasTextView.delegate = self
                    
                    
                    
                    cell.SubjectLabel.text = String( getSection[indexPath.section].subjectdetails[indexPath.row].subjectname)
                    
                    examHeaderId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                    
                    let calnder = UITapGestureRecognizer(target: self, action: #selector(CalanderVc))
                    cell.clanderView.addGestureRecognizer(calnder)
                    
                    
                    
                    let subjects = SaveSubject(target: self, action: #selector(saveVc))
                    subjects.checkBoxx = cell.subjectCheckBox
                    
                    subjects.subjectId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                    cell.subjectCheckBox.addGestureRecognizer(subjects)
                    
                    
                }
                
                
                
               
                }
                
            }
//
//
            
            else {

                cell.isUserInteractionEnabled = false
                cell.overAllView.isHidden = true

            }
            
            
        }
        
        
        
                   
        
        else {
            cell.sectionDropDownLabel.text = "Session"
            cell.calanderDateLabel.text = "DD/MM/YY"
            
            cell.sylubasTextView.text = "Syllabus"
            cell.sylubasTextView.textColor = UIColor.black
            cell.sylubasTextView.font = UIFont(name: "verdana", size: 11.0)
            
            let vc = NoonCell(target: self, action: #selector(NoonVc))
            vc.noonClick = cell.sectionDropDownView
            vc.noonLabel = cell.sectionDropDownLabel
            cell.sectionDropDownView.addGestureRecognizer(vc)
            
            
            cell.venuLabel.returnKeyType = .done
            cell.venuLabel.delegate = self
            cell.sylubasTextView.returnKeyType = .done
            cell.sylubasTextView.delegate = self
            
            
            
            cell.SubjectLabel.text = String( getSection[indexPath.section].subjectdetails[indexPath.row].subjectname)
            
            examHeaderId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
            
            let calnder = UITapGestureRecognizer(target: self, action: #selector(CalanderVc))
            cell.clanderView.addGestureRecognizer(calnder)
            
            
            
            let subjects = SaveSubject(target: self, action: #selector(saveVc))
            subjects.checkBoxx = cell.subjectCheckBox
            
            subjects.subjectId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
            cell.subjectCheckBox.addGestureRecognizer(subjects)
            
      }
        
        
//
//        if   sectionIdForEdit  ==  getSection[indexPath.row].sectionid {
//
//
//            let cell1 = tableView.dequeueReusableHeaderFooterView(withIdentifier: identifier2) as!
//            GetSectionYearHeaderFooterView
//            if indexPath.row == 0 {
//                cell1.headerTop.constant = 0
//                cell1.headerHeight.constant = 36
//                print("cell1.",cell1.headerHeight.constant)
//            }else if indexPath.row == 1{
//
//
//
//                cell.overallView.backgroundColor = .red
//
//                //                    var cell = Tv.cellForRowAtIndexPath(section)
//                //                          cell.frame.height = 10
//                cell1.headerTop.constant = 50
//                //                    cell1.headerHeight.constant = 36
//                print("cell1.",cell1.headerHeight.constant)
//            }
//
//        }
        
        
        return cell
        
    }
    
    
    @IBAction func NoonVc(ges : NoonCell){
        
        
        let  myArray = ["An","Fn"]
        
        dropDown.dataSource = myArray//4
        dropDown.anchorView = ges.noonClick
        
        dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
        
        dropDown.direction = .bottom
        DropDown.appearance().backgroundColor = UIColor.white
        dropDown.show() //7
        //        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
        
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            ges.noonLabel.text = item
            
            //            drop = item
            
            
            
            
            
            
            
            
            //            else if  item == "Text"{
            //
            //                print("Text")
            //                uploadView.isHidden = true
            //                //                    uploadImageView.isHidden = false
            //                //                    uploadTextLabel.isHidden = false
            //                //
            //                //
            //            }
            
        }
        
        
    }
    
    @IBAction func saveVc(gesture : SaveSubject ){
        
        
        
        
        print("check")
        
        
        
        if gesture.checkBoxx.isChecked == true{
            
            
            gesture.checkBoxx.isChecked = false
            
            gesture.checkBoxx.setImage(UIImage.init(named: "Verify"), for: .normal)
            
            //            sunjectIds.removeLast()
            
            
            
        }
        
        
        else {
            
            gesture.checkBoxx.isChecked = true
            
            //
            gesture.checkBoxx.setImage(UIImage.init(named: "verified"), for: .normal)
            
            
            
            
            
            
            
            
            //               selectedList1.append(["subjectID " :[gesture.subjectId]])
            //                sunjectIds.append(gesture.subjectId)
            //
            //                print("selectedList2",selectedList1)
            
        }
        
        //
        
        
    }
    
    
    
    
    
    @IBAction func saveVcc( ges : SaveSubject){
        
        //        getSaveViewModal
        
       
        saveButtonId = "1"
        
        var index = IndexPath(row: indexPathss, section: indexPathsections)
        
        
        //
        
        
        if EditId == "1"{
            let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
            
            
            if cell.sylubasTextView.text == "Syllabus"{
                
                SweetAlert().showAlert("Info", subTitle: "Please Enter Syllabus", style: .none, buttonTitle: "ok")
                
                
            }
            
            else if cell.venuLabel.text == ""{
                
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Enter Venue", style: .none, buttonTitle: "ok")
                
            }
            
            
            else if cell.calanderDateLabel.text ==  "DD/MM/YY" {
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Date", style: .none, buttonTitle: "ok")
                
            }
            else if  cell.sectionDropDownLabel.text == "Session"{
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Session", style: .none, buttonTitle: "ok")
                
            }
            
            else if ges.subjectId == ""{
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Subject", style: .none, buttonTitle: "ok")
                
            }
            
            
            
            else{
                let sujectData = EditSubjectDetailsRef()
                
                for i in sectiondetails{
                    
                    
                    
                    
                    print(" i.clgsectionid", i.clgsectionid)
                    sujectData.examsyllabus = i.clgsectionid + "/ " + cell.sylubasTextView.text
                    
                    sujectData.examvenue = i.clgsectionid + "/ " + cell.venuLabel.text!
                    sujectData.examdate = i.clgsectionid + "/ " + cell.calanderDateLabel.text!
                    sujectData.examsession =  i.clgsectionid + "/ " + cell.sylubasTextView.text
                    sujectData.examsubjectid = i.clgsectionid + "/ " + ges.subjectId
                    sujectData.examsession = i.clgsectionid + "/ " + cell.sectionDropDownLabel.text!
                    
                    
                    
                    
                }
                
                saveEdit.append(sujectData)
                //        SubjectdetailssujectData.append()
                
                
                SweetAlert().showAlert("Info", subTitle: "Given Data SuccessFully Edit ", style: .none, buttonTitle: "ok")
                
                
                print(" i.sujectData", sujectData)
                
                
                print("sujectDatasujectData",sujectData.examvenue,ges.subjectId,sujectData.examsyllabus)
                
            }
        }
        
        
        else{
            
            
            let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
            
            
            if cell.sylubasTextView.text == "Syllabus"{
                
                SweetAlert().showAlert("Info", subTitle: "Please Enter Syllabus", style: .none, buttonTitle: "ok")
                
                
            }
            
            else if cell.venuLabel.text == ""{
                
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Enter Venue", style: .none, buttonTitle: "ok")
                
            }
            
            
            else if cell.calanderDateLabel.text ==  "DD/MM/YY" {
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Date", style: .none, buttonTitle: "ok")
                
            }
            else if  cell.sectionDropDownLabel.text == "Session"{
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Session", style: .none, buttonTitle: "ok")
                
            }
            
            else if ges.subjectId == ""{
                
                
                SweetAlert().showAlert("Info", subTitle: "Please Select Subject", style: .none, buttonTitle: "ok")
                
            }
            
            
            
            else{
                let sujectData = SubjectDetailsRef()
                
                for i in clgsection{
                    
                    
                    
                    
                    print(" i.clgsectionid", i.clgsectionid)
                    sujectData.examsyllabus = i.clgsectionid + "/ " + cell.sylubasTextView.text
                    
                    sujectData.examvenue = i.clgsectionid + "/ " + cell.venuLabel.text!
                    sujectData.examdate = i.clgsectionid + "/ " + cell.calanderDateLabel.text!
                    sujectData.examsession =  i.clgsectionid + "/ " + cell.sylubasTextView.text
                    sujectData.examsubjectid = i.clgsectionid + "/ " + ges.subjectId
                    sujectData.examsession = i.clgsectionid + "/ " + cell.sectionDropDownLabel.text!
                    
                    
                    
                    
                }
                
                saves.append(sujectData)
                //        SubjectdetailssujectData.append()
                
                
                SweetAlert().showAlert("Info", subTitle: "Given Data SuccessFully Saved", style: .none, buttonTitle: "ok")
                
                
                print(" i.sujectData", sujectData)
                
                
                print("sujectDatasujectData",sujectData.examvenue,sujectData.examsubjectid,sujectData.examsyllabus)
                
            }
            
        }
        
    }
    
    
    
    
    
    
    
    
    @IBAction func CalanderVc(){
        
        
        let index = IndexPath(row: indexPathss, section: indexPathsections)
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
        
        
        
        
        datePickerSet.isHidden = false
        datePickerView.isHidden = false
        
        
     
        
        let dateFormater: DateFormatter = DateFormatter()
        dateFormater.dateFormat = "dd-M-yyyy"
        let startDateSet = startDate
        let date = dateFormater.date(from:startDateSet!)!
         var dt : Date!
        dt = date
        let currentDate2 = endDate
        let date2 = dateFormater.date(from:currentDate2!)!
         var dt2 : Date!
        dt2 = date2



        datePickerSet.minimumDate = dt
        datePickerSet.maximumDate = dt2


        let selectedDate = dateFormater.string(from: datePickerSet.date)
        print("selectedDate",selectedDate)
         
       
            
            cell.calanderDateLabel.text = selectedDate
            
    
    }
    
    
    
    @IBAction func dte(_ sender: UIDatePicker) {
        
        let index = IndexPath(row: indexPathss, section: indexPathsections)
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
        
             print("print \(sender.date)")

        let dateFormatter = DateFormatter()
          dateFormatter.dateFormat = "dd-M-yyyy"
        let somedateString = dateFormatter.string(from: sender.date)

        
        cell.calanderDateLabel.text = somedateString
        print(somedateString)
    }
    
    
//    func showDatePicker(){
//        //Formate Date
//        datePickerSet.datePickerMode = .date
//
//       //ToolBar
//       let toolbar = UIToolbar();
//       toolbar.sizeToFit()
//       let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
//        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
//      let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
//
//     toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
//
////      txtDatePicker.inputAccessoryView = toolbar
////      txtDatePicker.inputView = datePickerSet
//
//     }

//      @objc func donedatePicker(){
//          let index = IndexPath(row: indexPathss, section: indexPathsections)
//          let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
//
//
//       let formatter = DateFormatter()
//       formatter.dateFormat = "dd/MM/yyyy"
//          cell.calanderDateLabel.text = formatter.string(from: datePickerSet.date)
//       self.view.endEditing(true)
//     }
//
//     @objc func cancelDatePicker(){
//        self.view.endEditing(true)
//      }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        Tv.deselectRow(at: indexPath, animated: true)
        let cell = tableView.dequeueReusableCell(withIdentifier: identifiers, for: indexPath) as!
        GetSectionYearTableViewCell
        
        
        
        var index = indexPath.row
        
        
       
            
          
            if EditId == "1"{
                
              
                
                indexPathsections = indexPath.section
                
                
                
                //                  }
                
                
                if let selectedCells = selectedCell, selectedCells == indexPath {
                    
                    selectedCell = nil
                    
                    
                   
                    
                    
                    print("didSeleIddidSeleId",didSeleId)
                    
                    //            Tv.dataSource = self
                    
                    
                    cell.subjectCheckBox.isChecked = false
                    
                    
                    
                    
                } else {
                    
                    
//                    if  sectionIdForEdit == sectionsForCompar {
                        
                        
                        cell.overallView.isHidden = false
                    
                        
                       
                    selectedCell = indexPath
                    
                    
                    cell.subjectCheckBox.isChecked = true
                    
                    
                    //                   selId = getSection[indexPath.section].subjectdetails[indexPath.row].subjectid
                    
                    
                    let save = SaveSubject(target: self, action: #selector(saveVcc))
                    //        if seci == seci{
                    //            print("seciseciseciseci",seci)
                    save.subjectId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                    //        }
                    save.venus = cell.venuLabel.text
                    save.synal = cell.sylubasTextView.text
                    save.date = cell.calanderDateLabel.text
                    
                    
                    cell.SaveView.addGestureRecognizer(save)
                    
                    
                    
                    print("getSection[indexPath.section].subjectdetails[indexPath.row].subjectid",getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                    
                    //
                    
                    
                    
                    
                    
                    
                    //                   var index = indexPath.row
                    //
                    //
                    //
                    //
                    //                   let image = UIImage(named: "done")
                    ////                       cell.tickImage.image =  image
                    //                   cell.selectImg.image = image
                    //
                    //                   var selId : String!
                    //
                    //
                    //
                    //                   selId = getSection[indexPath.section].subjectdetails[indexPath.row].subjectid
                    //
                    //
                    //                   print("selId",selId)
                    //                   cell.selectImg.backgroundColor = .blue
                    //                   print("cell.selectImg.backgroundColor",cell.selectImg.backgroundColor)
                    //                   print("  cell.subjectid", getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                    //
                    //                   print("  cell.subjectCheckBox.isChecked",  cell.subjectCheckBox.isChecked)
                    //
                    //                   cell.subjectCheckBox.isChecked = true
                    //
                    //                   didSeleId = 1
                    //
                    //
                    //
                    //                   print("didSeleIddidSeleId",closedidSeleId)
                    //                   Tv.dataSource = self
                    //
                    //
                    //
                    ////                   -=
                    //
                    //
                    ////                   cell.subjectCheckBox.setImage(UIImage.init(named: "done"), for: .normal)
                    //
                    //
                    //                   print("offf")
                    //                   print("jkuuu",selectedCell)
                    
                    indexPathss = indexPath.row
                    ////
                    ////
                    //
                    //
                    //
                    //
                    //
                    //
                    //
                    //
                }
                
//            }
            
            
           
        }
        
        else{
            
            
            indexPathsections = indexPath.section
            
            
            
            if let selectedCells = selectedCell, selectedCells == indexPath {
                
                selectedCell = nil
                
                
                print("didSeleIddidSeleId",didSeleId)
                
                //            Tv.dataSource = self
                
                
                cell.subjectCheckBox.isChecked = false
                
                
                
                
            } else {
                
                selectedCell = indexPath
                
                
                cell.subjectCheckBox.isChecked = true
                
                
                //                   selId = getSection[indexPath.section].subjectdetails[indexPath.row].subjectid
                
                
                let save = SaveSubject(target: self, action: #selector(saveVcc))
                //        if seci == seci{
                //            print("seciseciseciseci",seci)
                save.subjectId = ( getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                //        }
                save.venus = cell.venuLabel.text
                save.synal = cell.sylubasTextView.text
                save.date = cell.calanderDateLabel.text
                
                
                cell.SaveView.addGestureRecognizer(save)
                
                print("getSection[indexPath.section].subjectdetails[indexPath.row].subjectid",getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                
                //
                
                
                
                
                
                
                //                   var index = indexPath.row
                //
                //
                //
                //
                //                   let image = UIImage(named: "done")
                ////                       cell.tickImage.image =  image
                //                   cell.selectImg.image = image
                //
                //                   var selId : String!
                //
                //
                //
                //                   selId = getSection[indexPath.section].subjectdetails[indexPath.row].subjectid
                //
                //
                //                   print("selId",selId)
                //                   cell.selectImg.backgroundColor = .blue
                //                   print("cell.selectImg.backgroundColor",cell.selectImg.backgroundColor)
                //                   print("  cell.subjectid", getSection[indexPath.section].subjectdetails[indexPath.row].subjectid)
                //
                //                   print("  cell.subjectCheckBox.isChecked",  cell.subjectCheckBox.isChecked)
                //
                //                   cell.subjectCheckBox.isChecked = true
                //
                //                   didSeleId = 1
                //
                //
                //
                //                   print("didSeleIddidSeleId",closedidSeleId)
                //                   Tv.dataSource = self
                //
                //
                //
                ////                   -=
                //
                //
                ////                   cell.subjectCheckBox.setImage(UIImage.init(named: "done"), for: .normal)
                //
                //
                //                   print("offf")
                //                   print("jkuuu",selectedCell)
                
                indexPathss = indexPath.row
                ////
                ////
                //
                //
                //
                //
                //
                //
                //
                //
            }
            
            
        }
        //
        //        
        //        Tv.beginUpdates()
        //        Tv.endUpdates()
        //        Tv.reloadData()
        //
        Tv .reloadRows(at: [indexPath], with: .automatic)
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
        
        
        if let selectedCell = selectedCell, selectedCell == indexPath {
            
            return 317
            
        } else {
            
//            if GetsectioId == 1 {
//                return 0
//
//            }
            
            return 50
            
        }
        
        
        
        
        //
        //             if selectedIndex == indexPath.row && isclosaps == true {
        //
        //                 return 317
        //             }
        //
        //             else{
        //
        //                 return 50
        //
        //
        //
        //             }
        //
    }
    
    func GetSectionAndYear(){
        
        let section = getSubjectWiseSectionModal()
        
        section.userid = userId
        section.appid = "2"
        section.semesterid = semsterID
        
        
        let sectionStr = section.toJSONString()
        
        
        
        //        print("yearAndSectionModalStr",section)
        
        getSectionWiseRequest.call_request(param: sectionStr!) {
            
            [self]  (res) in
            
            
            
            
            
            let particular : getSubjectWiseResponce = Mapper<getSubjectWiseResponce>().map(JSONString: res)!
            
            
            
            getSection = particular.data
            
            
            
            if particular.Status == 1 {
                
                for i in particular.data{
                    
                    
                    GetSectionNmeRef = i.subjectdetails
                    
                }
                nodataView.isHidden = true
                noDataLabel.isHidden = true
                
                Tv.dataSource = self
                Tv.delegate = self
                Tv.reloadData()
                
                
            }else{
                nodataView.isHidden = false
                noDataLabel.isHidden = false
                noDataLabel.text = particular.Message
                Tv.dataSource = self
                Tv.delegate = self
                Tv.reloadData()
                
            }
            
            
            
        }
        
        
        
        
        
        
    }
    
    
    func createExam(){
        
//        var examEditresp : [exameEditMainDetail] = []
//        var examEditsModalApi : [EditSubjectDetailsRef] = []
//        var sectiondetails: [EditSectiondetailRef] = []
        
        if EditId == "1"{
            
            
            if saveButtonId == "1"{
                var sections : [Sectiondetails] = []
                
                
                print("clgsection.count",sectiondetails.count)
                
                
                
                
                let createExam = Main()
                
                
                for z in 0..<ExameSection.count{
                    
                    
                    createExam.examname = ExameSection[z].examnm
                    createExam.staffid = userId
                    createExam.collegeid = colgId
                    createExam.examid = ExameSection[z].examheaderid
                    createExam.enddate =  ExameSection[z].enddate
                    createExam.startdate =  ExameSection[z].startdate
                    createExam.processtype = "edit"
                    
                    //            clgsection = examCre[z].sectiondetails
                    
                    
                    for i in 0..<sectiondetails.count{
                        
                        print("clgsection.count-1",sectiondetails.count)
                        print("iewrrr",i)
                        let sectionDetails  =  Sectiondetails()
                        
                        
                        
                        sectionDetails.clgsectionid = sectiondetails[i].clgsectionid
                        
                        sectionDetails.clgdepartmentid = clgDepartId
                        
                        
                        sections.append(sectionDetails)
                        
                        var sujectData : [Subjectdetails] = []
                        for ik in 0..<(saveEdit.count)
                        {
                            
                            print("poopoppop",saveEdit.count-1)
                            
                            //
                            
                            let subjectdetails  =  Subjectdetails()
                            
                            if (saveEdit[ik].examsyllabus.contains(sectiondetails[i].clgsectionid) ) && (saveEdit[ik].examvenue.contains(sectiondetails[i].clgsectionid) ) && (saveEdit[ik].examdate.contains(sectiondetails[i].clgsectionid) ) && (saveEdit[ik].examsubjectid.contains(sectiondetails[i].clgsectionid) ) {
                                
                                
                                
                                print("iops",saveEdit.count)
                                
                                
                                
                                
                                
                                let date = saveEdit[ik].examdate;
                                let resultdate = date!.split(separator: " ")
                                print("result",resultdate)
                                print(resultdate[0]) // Hello
                                print(resultdate[1])
                                
                                
                                subjectdetails.examdate =  String(resultdate[1])
                                
                                
                                let venu = saveEdit[ik].examvenue;
                                let resultvenu = venu!.split(separator: " ")
                                print("result",resultvenu)
                                print(resultvenu[0]) // Hello
                                print(resultvenu[1])
                                
                                
                                subjectdetails.examvenue = String(resultvenu[1])
                                
                                
                                
                                subjectdetails.examsession = "An"
                                
                                let sylubas = saveEdit[ik].examsyllabus;
                                let resultsylubs = sylubas!.split(separator: " ")
                                print("result",resultsylubs)
                                print(resultsylubs[0]) // Hello
                                print(resultsylubs[1])
                                
                                
                                subjectdetails.examsyllabus = String(resultsylubs[1])
                                
                                
                                
                                
                                
                                
                                
                                
                                let sayHello = saveEdit[ik].examsubjectid;
                                let result = sayHello!.split(separator: " ")
                                print("result",result)
                                print(result[0]) // Hello
                                print(result[1])
                                
                                
                                
                                
                                subjectdetails.examsubjectid = String(result[1])
                                
                                
                                
                                
                                
                                sujectData.append(subjectdetails)
                                
                            }
                            
                            
                            
                            
                        }
                        
                        
                        sectionDetails.subjectdetails = sujectData
                        
                        
                        
                    }
                    
                    createExam.sectiondetails = sections
                    
                    
                }
                
                let createExamStr = createExam.toJSONString()
                
                
                print("createExamStr",createExamStr)
                examAddSubRequest.call_request(param: createExamStr!) {
                    //
                    [self]  (res) in
                    
                    
                    let exams : ExaminationAddResponce = Mapper<ExaminationAddResponce>().map(JSONString: res)!
                    
                    
                    //                examSubRef = exams.data
                    
                    if exams.status == 1 {
                        
                        
                        SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                        
                        Tv.dataSource = self
                        Tv.delegate = self
                        Tv.reloadData()
                        
                        
                        
                    }
                    
                    else{
                        
                        
                        SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                        
                        Tv.dataSource = self
                        Tv.delegate = self
                        Tv.reloadData()
                        
                        
                    }
                    
                    
                    
                    
                }
                
            }else{
                
                
                
                
                
                var sections : [Sectiondetails] = []
                
                
                print("clgsection.count",sectiondetails.count)
                
                
                
                
                let createExam = Main()
                
                
                for z in 0..<ExameSection.count{
                    
                    
                    createExam.examname = ExameSection[z].examnm
                    createExam.staffid = userId
                    createExam.collegeid = colgId
                    createExam.examid = ExameSection[z].examheaderid
                    createExam.enddate =  ExameSection[z].enddate
                    createExam.startdate =  ExameSection[z].startdate
                    createExam.processtype = "edit"
                    
                    //            clgsection = examCre[z].sectiondetails
                    
                    
                    for i in 0..<sectiondetails.count{
                        
                        print("clgsection.count-1",sectiondetails.count)
                        print("iewrrr",i)
                        let sectionDetails  =  Sectiondetails()
                        
                        
                        
                        sectionDetails.clgsectionid = sectionsForCompar
                        
                        sectionDetails.clgdepartmentid = clgDepartId
                        
                        
                        sections.append(sectionDetails)
                        
                        var sujectData : [Subjectdetails] = []
                        for ik in examEditsModalApi
                        {
                            
                            print("poopoppop",examEditsModalApi.count-1)
                            
                            //
                            
                            let subjectdetails  =  Subjectdetails()
                            
//                            if (examEditsModalApi[ik].examsyllabus.contains(sectiondetails[i].clgsectionid) ) && (examEditsModalApi[ik].examvenue.contains(sectiondetails[i].clgsectionid) ) && (examEditsModalApi[ik].examdate.contains(sectiondetails[i].clgsectionid) ) && (examEditsModalApi[ik].examsubjectid.contains(sectiondetails[i].clgsectionid) ) {
                                
                                
                                
                                print("iops",examEditsModalApi.count)
                                
                                
                                
                                
                                
//                                let date = examEditsModalApi[ik].examdate;
//                                let resultdate = date!.split(separator: " ")
//                                print("result",resultdate)
//                                print(resultdate[0]) // Hello
//                                print(resultdate[1])
//
                                
                                subjectdetails.examdate = ik.examdate
                                
                                
//                                let venu = examEditsModalApi[ik].examvenue;
//                                let resultvenu = venu!.split(separator: " ")
//                                print("result",resultvenu)
//                                print(resultvenu[0]) // Hello
//                                print(resultvenu[1])
//
                                
                                subjectdetails.examvenue = ik.examvenue
                                
                                
                                
                                subjectdetails.examsession = "An"
                                
//                                let sylubas = examEditsModalApi[ik].examsyllabus;
//                                let resultsylubs = sylubas!.split(separator: " ")
//                                print("result",resultsylubs)
//                                print(resultsylubs[0]) // Hello
//                                print(resultsylubs[1])
//
                                
                                subjectdetails.examsyllabus = ik.examsyllabus
                                
                                
                                
                                
                                
                                
                                
//                                
//                                let sayHello = examEditsModalApi[ik].examsubjectid;
//                                let result = sayHello!.split(separator: " ")
//                                print("result",result)
//                                print(result[0]) // Hello
//                                print(result[1])
                                
                                
                                
                                
                                subjectdetails.examsubjectid = ik.examsubjectid
                                
                                
                                
                                
                                
                                sujectData.append(subjectdetails)
                                
//                            }
                            
                            
                            
                            
                        }
                        
                        
                        sectionDetails.subjectdetails = sujectData
                        
                        
                        
                    }
                    
                    createExam.sectiondetails = sections
                    
                    
                }
                
                let createExamStr = createExam.toJSONString()
                
                
                print("createExamStr",createExamStr)
                examAddSubRequest.call_request(param: createExamStr!) {
                    //
                    [self]  (res) in
                    
                    
                    let exams : ExaminationAddResponce = Mapper<ExaminationAddResponce>().map(JSONString: res)!
                    
                    
                    //                examSubRef = exams.data
                    
                    if exams.status == 1 {
                        
                        
                        SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                        
                        Tv.dataSource = self
                        Tv.delegate = self
                        Tv.reloadData()
                        
                        
                        
                    }
                    
                    else{
                        
                        
                        SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                        
                        Tv.dataSource = self
                        Tv.delegate = self
                        Tv.reloadData()
                        
                        
                    }
                    
                    
                    
                    
                }
                
                
                
                
            }
            
            
           
            
        }
        
        else{
            
            
            
            var sections : [Sectiondetails] = []
            
            
            print("clgsection.count",clgsection.count)
            
            
            
            
            let createExam = Main()
            
            
            for z in 0..<examCre.count{
                
                
                createExam.examname = examCre[z].examname
                createExam.staffid = userId
                createExam.collegeid = colgId
                createExam.examid = "0"
                createExam.enddate =  examCre[z].enddate
                createExam.startdate =  examCre[z].startdate
                createExam.processtype = "add"
                
                //            clgsection = examCre[z].sectiondetails
                
                
                for i in 0..<clgsection.count{
                    
                    print("clgsection.count-1",clgsection.count)
                    print("iewrrr",i)
                    let sectionDetails  =  Sectiondetails()
                    
                    
                    
                    sectionDetails.clgsectionid = clgsection[i].clgsectionid
                    
                    sectionDetails.clgdepartmentid = clgDepartId
                    
                    
                    sections.append(sectionDetails)
                    
                    var sujectData : [Subjectdetails] = []
                    for ik in 0..<(saves.count)
                    {
                        
                        print("poopoppop",saves.count-1)
                        
                        //
                        
                        let subjectdetails  =  Subjectdetails()
                        
                        if (saves[ik].examsyllabus.contains(clgsection[i].clgsectionid) ) && (saves[ik].examvenue.contains(clgsection[i].clgsectionid) ) && (saves[ik].examdate.contains(clgsection[i].clgsectionid) ) && (saves[ik].examsubjectid.contains(clgsection[i].clgsectionid) ) {
                            
                            
                            
                            print("iops",saves.count)
                            
                            
                            
                            
                            
                            let date = saves[ik].examdate;
                            let resultdate = date!.split(separator: " ")
                            print("result",resultdate)
                            print(resultdate[0]) // Hello
                            print(resultdate[1])
                            
                            
                            subjectdetails.examdate =  String(resultdate[1])
                            
                            
                            let venu = saves[ik].examvenue;
                            let resultvenu = venu!.split(separator: " ")
                            print("result",resultvenu)
                            print(resultvenu[0]) // Hello
                            print(resultvenu[1])
                            
                            
                            subjectdetails.examvenue = String(resultvenu[1])
                            
                            
                            
                            subjectdetails.examsession = "An"
                            
                            let sylubas = saves[ik].examsyllabus;
                            let resultsylubs = sylubas!.split(separator: " ")
                            print("result",resultsylubs)
                            print(resultsylubs[0]) // Hello
                            print(resultsylubs[1])
                            
                            
                            subjectdetails.examsyllabus = String(resultsylubs[1])
                            
                            
                            
                            
                            
                            
                            
                            
                            let sayHello = saves[ik].examsubjectid;
                            let result = sayHello!.split(separator: " ")
                            print("result",result)
                            print(result[0]) // Hello
                            print(result[1])
                            
                            
                            
                            
                            subjectdetails.examsubjectid = String(result[1])
                            
                            
                            
                            
                            
                            sujectData.append(subjectdetails)
                            
                        }
                        
                        
                        
                        
                    }
                    
                    
                    sectionDetails.subjectdetails = sujectData
                    
                    
                    
                }
                
                createExam.sectiondetails = sections
                
                
            }
            
            let createExamStr = createExam.toJSONString()
            
            
            print("createExamStr",createExamStr)
            examAddSubRequest.call_request(param: createExamStr!) {
                //
                [self]  (res) in
                
                
                let exams : ExaminationAddResponce = Mapper<ExaminationAddResponce>().map(JSONString: res)!
                
                
                examSubRef = exams.data
                
                if exams.status == 1 {
                    
                    
                    SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                    
                    Tv.dataSource = self
                    Tv.delegate = self
                    Tv.reloadData()
                    
                    
                    
                }
                
                else{
                    
                    
                    SweetAlert().showAlert("Info", subTitle: exams.message, style: .none, buttonTitle: "ok")
                    
                    Tv.dataSource = self
                    Tv.delegate = self
                    Tv.reloadData()
                    
                    
                }
                
                
                
                
            }
        }
    }
    
    
    
    
    
    
    
    
    
    @IBAction func backBtn(_ sender: Any) {
        
        dismiss(animated: true)
        
        
        
    }
    
    // Tab Bar Nagivation
    
    
    // tap bar View
    
    
    
    
    @IBAction func helpRedirect() {
        
        let vc = HelpViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func termsAndCondition() {
        
        let vc = MenuTermsViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func logoutPressed() {
        
        
        _ =  SweetAlert().showAlert(" Are you sure do you want to logout ",subTitle: "",style: .none,buttonTitle: "NO",buttonColor:.systemGray,otherButtonTitle: "YES",otherButtonColor: .systemGray){
            is_yes_click in
            if is_yes_click {
                print("pressed no button")
            }else{
                
                UserDefaults.standard.removeObject(forKey: DefaultsKeys.mobileNumber)
                
                let vc = LoginViewController(nibName: nil, bundle: nil)
                vc.modalPresentationStyle = .fullScreen
                
                self.present(vc, animated: true, completion: nil)
            }
        }
    }
    
    
    @IBAction func faqRedirect() {
        print("faqRedirect")
        let vc = FaqViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
    }
    
    @IBAction func privacyPolicyRedirect() {
        
        let vc = PrivacyPolicyViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
    }
    
    
    
    
    
    @IBAction func refreshVc() {
        
        print("refreshVcWork")
        KRProgressHUD.show()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
            //            self.tv.reloadData()
            
            
            KRProgressHUD.dismiss()
            
        }
        
        
    }
    
    
    @IBAction func notificationVc() {
        print("NotificationViewController")
        let vc = NotificationViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: false, completion: nil)
        
        //        vc.modalPresentationStyle = .fullScreen
        
    }
    
    
    
    
    @IBAction func menu() {
        
        if sideMenuView.isHidden == true{
            
            sideMenuView.isHidden = false
            //
            
            print("menuVisble")
        }
        
        else{
            
            sideMenuView.isHidden = true
            //            self.view.sendSubviewToBack(sideMenuView)
            print("mddffenuVisble")
        }
        
        
    }
    
    
    @IBAction func changePassowrdVC(){
        
        let vc = ChangePasswordViewController(nibName: nil, bundle: nil)
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
        //        present(vc, animated: false, completion: nil)
        
        
    }
    
    
    
    
    
    
    
    
    @IBAction func priorityVc() {
        
        
        
        
        
        
        let login = LoginModal ()
        login.mobilenumber = MobileNumber
        login.Password = password
        print("passsdded", login.Password)
        
        
        let loginStr = login.toJSONString()
        
        loginRequest.call_request(param: loginStr!){ [self]
            
            (res) in
            
            
            let loginResponse : LoginResponse =
            Mapper<LoginResponse>().map(JSONString: res)!
            
            loginDatas = loginResponse.data
            print("ctrss",loginDatas.count)
            if (loginResponse.data.count >= 1){
                
                
                
                let vc = PriorityViewController(nibName: nil, bundle: nil)
                vc.loginData = loginResponse.data
                print("logddd",loginResponse.data)
                vc.modalPresentationStyle = .fullScreen
                
                present(vc, animated: true,completion: nil)
                
                
                
            }
        }
        
        
        
        
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        var index = IndexPath(row: indexPathss, section: indexPathsections)


        //
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
        
        cell.venuLabel.resignFirstResponder()
        return true
    }
    
    
    
    
    
    
    
    
//
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {

        var index = IndexPath(row: indexPathss, section: indexPathsections)


        //
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell

        if text == "\n" {
            cell.sylubasTextView.resignFirstResponder()
            return false
        }
        return true
    }



    func textViewDidEndEditing(_ textView: UITextView) {
        print("false")

        var index = IndexPath(row: indexPathss, section: indexPathsections)


        //
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell
        if cell.sylubasTextView.text == "" {
            cell.sylubasTextView.text = "Syllabus"
            cell.sylubasTextView.textColor = UIColor.black
            cell.sylubasTextView.font = UIFont(name: "verdana", size: 13.0)
//            let selectRecpient = UITapGestureRecognizer(target: self, action: #selector(SelectRepVc))
//            selectRecipientsView.addGestureRecognizer(selectRecpient)

        }
    }




    func textViewDidBeginEditing(_ textView: UITextView) {

        print("true")

        var index = IndexPath(row: indexPathss, section: indexPathsections)


        //
        let cell: GetSectionYearTableViewCell = self.Tv.cellForRow(at: index) as! GetSectionYearTableViewCell


        if cell.sylubasTextView.text == "Syllabus" {
            cell.sylubasTextView.text = ""
            cell.sylubasTextView.textColor = UIColor.black
            cell.sylubasTextView.font = UIFont(name: "verdana", size: 14.0)
        }
    }
    
    
    
}
class SelectSubject : UITapGestureRecognizer{
    
    
    var  checkBoxx : CheckBoxThree!
    
    var  subjectId : String!
    
    var sectionID : String!
    
    var index : IndexPath!
    
    
}

class SaveSubject : UITapGestureRecognizer{
    
    
//    var  checkBoxx : CheckBoxTwo!
    var  checkBoxx : CheckBoxThree!
    
    var  subjectId : String!

    var venus : String!
    var synal : String!
    var date : String!
    
    var height  : Int!
    
}


class Save : UITapGestureRecognizer{
    
    
//    var  checkBoxx : CheckBoxTwo!
//    var  checkBoxx : CheckBoxTwo!
    
    var  subjectId : String!

    var venu : String!
    var synal : String!
    var date : String!
    
    
}


class getSaveViewModal : Mappable  {

   

    

   

    var venue : String!

    var syllabus : String!

    var date : String!

    var sectionId : [String] = []
    
    var subjeID : String!
    
    
    
    

    init(){}

    

    

    required init?(map: ObjectMapper.Map) {

        mapping(map: map)

    }

    
    

    

    func mapping(map: ObjectMapper.Map) {

//        venue

    }

    

}


class HeaderTapGesture : UITapGestureRecognizer{
    
    
    var tagss : Int!
    
    
}


class NoonCell : UITapGestureRecognizer{
    
    
    var noonClick : UIView!
    var noonLabel : UILabel!
    
}

